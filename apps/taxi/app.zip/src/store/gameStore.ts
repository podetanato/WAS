import { create } from 'zustand';
import * as THREE from 'three';
import { MapData } from '../utils/mapLogic';
import { loadWASData, saveWASData, clearWASData, WASSaveData } from '../utils/wasBridge';

export type GameState = 'START' | 'PLAYING' | 'GAME_OVER';

export interface Passenger {
  id: string;
  pos: THREE.Vector3;
  destinationPos: THREE.Vector3;
  fareBonus: number;
  name: string;
}

export interface NPCCarData {
  id: string;
  pos: THREE.Vector3;
  angle: number;
  speed: number;
  color: string;
  type: number; // 0: sedan, 1: suv, 2: compact
}

export interface CarUpgrades {
  topSpeed: number;    // Level 1-5 (Max speed & acceleration)
  acceleration: number;// Level 1-5 (Throttle torque)
  handling: number;    // Level 1-5 (Grip & turning sharpness)
  nitro: number;       // Level 1-5 (Nitro boost duration/speed)
  spoiler: number;     // 0: none, 1: sport, 2: GT, 3: Cyber
  neonColor: string;   // Underglow neon color
  bodyColor: string;   // Car Paint color
}

interface GameStore {
  score: number;
  gameState: GameState;
  hasPassenger: boolean;
  activePassenger: Passenger | null;
  passengers: Passenger[];
  npcCars: NPCCarData[];
  message: string;
  mapData: MapData | null;
  carPos: THREE.Vector3;
  carAngle: number;
  carSpeed: number;
  carGear: number;
  isDrifting: boolean;
  passengerDistance: number;
  currentFare: number;
  meterDistance: number;
  cameraMode: 'TPS' | 'FPS'; // 視点モード (TPS: 3人称 / FPS: 1人称・運転席視点)
  
  // Settings
  isSettingsOpen: boolean;
  showControls: boolean;
  enableShadows: boolean;
  ultraLowMode: boolean; // ウルトラ低負荷モード
  soundVolume: number;
  bgmGenre: 'none' | 'Lo-fi' | 'Jazz' | 'Synthwave'; // BGM設定
  fps: number; // 常時表示用リアルタイムFPS

  // Car Upgrades & Garage
  isGarageOpen: boolean;
  carModel: 'classic' | 'sport' | 'hyper';
  ownedCars: ('classic' | 'sport' | 'hyper')[];
  carUpgrades: CarUpgrades;
  nitroLeft: number;      // 0 - 100
  isNitroActive: boolean;

  // WAS (Web App Store) Stats & Sync
  passengersDelivered: number;
  totalFaresEarned: number;
  lastSavedAt: number | null;

  setScore: (score: number) => void;
  setGameState: (state: GameState) => void;
  setPassengers: (passengers: Passenger[]) => void;
  pickUpPassenger: (passenger: Passenger) => void;
  dropOffPassenger: () => void;
  setNPCCars: (cars: NPCCarData[]) => void;
  addScore: (points: number) => void;
  setMessage: (msg: string) => void;
  setMapData: (mapData: MapData) => void;
  setCarStatus: (pos: THREE.Vector3, angle: number, speed: number, gear: number, isDrifting: boolean) => void;
  addPassengerDistance: (dist: number) => void;
  
  // Settings Actions
  toggleSettings: () => void;
  updateSettings: (settings: Partial<{showControls: boolean; enableShadows: boolean; ultraLowMode: boolean; soundVolume: number; bgmGenre: 'none' | 'Lo-fi' | 'Jazz' | 'Synthwave'; cameraMode: 'TPS' | 'FPS'}>) => void;
  setFps: (fps: number) => void;
  toggleCameraMode: () => void;
  setCameraMode: (mode: 'TPS' | 'FPS') => void;

  // Garage & Upgrade Actions
  toggleGarage: () => void;
  buyUpgrade: (type: 'topSpeed' | 'acceleration' | 'handling' | 'nitro' | 'spoiler') => boolean;
  buyCar: (model: 'classic' | 'sport' | 'hyper', price: number) => boolean;
  setCarModel: (model: 'classic' | 'sport' | 'hyper') => void;
  setBodyColor: (color: string) => void;
  setNeonColor: (neon: string) => void;
  useNitro: (active: boolean) => void;
  updateNitroGauge: (delta: number) => void;

  // WAS Persistence Actions
  saveGame: () => void;
  resetGame: () => void;
  loadGame: (externalData?: Partial<WASSaveData>) => void;
}

// Initial WAS load
const initialWAS = loadWASData();

export const useGameStore = create<GameStore>((set, get) => ({
  score: initialWAS.score || 0,
  gameState: 'START',
  hasPassenger: false,
  activePassenger: null,
  passengers: [],
  npcCars: [],
  message: '街を走り回り、5人の乗客から好きな客を拾おう！ (Spaceでドリフト, Gキーでガレージ)',
  mapData: null,
  carPos: new THREE.Vector3(0, 0, 0),
  carAngle: 0,
  carSpeed: 0,
  carGear: 1,
  isDrifting: false,
  passengerDistance: 0,
  currentFare: 0,
  meterDistance: 0,
  cameraMode: initialWAS.settings.cameraMode || 'TPS',
  
  isSettingsOpen: false,
  showControls: initialWAS.settings.showControls ?? true,
  enableShadows: initialWAS.settings.enableShadows ?? true,
  ultraLowMode: initialWAS.settings.ultraLowMode ?? false,
  soundVolume: initialWAS.settings.soundVolume ?? 0.5,
  bgmGenre: initialWAS.settings.bgmGenre || 'none',
  fps: 60,

  isGarageOpen: false,
  carModel: initialWAS.carModel || 'classic',
  ownedCars: initialWAS.ownedCars || ['classic'],
  carUpgrades: initialWAS.carUpgrades || {
    topSpeed: 1,
    acceleration: 1,
    handling: 1,
    nitro: 1,
    spoiler: 0,
    neonColor: '#38bdf8',
    bodyColor: '#fbbf24',
  },
  nitroLeft: 100,
  isNitroActive: false,

  passengersDelivered: initialWAS.stats.passengersDelivered || 0,
  totalFaresEarned: initialWAS.stats.totalFaresEarned || 0,
  lastSavedAt: initialWAS.updatedAt || null,

  setScore: (score) => {
    set({ score });
    get().saveGame();
  },
  setGameState: (gameState) => set({ gameState }),
  setPassengers: (passengers) => set({ passengers }),
  pickUpPassenger: (passenger) => set((state) => ({
    hasPassenger: true,
    activePassenger: passenger,
    passengers: state.passengers.filter(p => p.id !== passenger.id),
    passengerDistance: 0,
    currentFare: 12 + passenger.fareBonus, // Initial base fare
    meterDistance: 0,
    message: `${passenger.name} を乗せました！ 目的地へ急ごう！`
  })),
  dropOffPassenger: () => {
    const s = get();
    const fareEarned = Math.floor(s.currentFare);
    const newScore = s.score + fareEarned;
    const newDelivered = s.passengersDelivered + 1;
    const newTotalFares = s.totalFaresEarned + fareEarned;

    set({
      hasPassenger: false,
      activePassenger: null,
      score: newScore,
      passengerDistance: 0,
      message: `到着！ 運賃 $${fareEarned} を獲得！ (合計送迎: ${newDelivered}人)`,
      currentFare: 0,
      meterDistance: 0,
      passengersDelivered: newDelivered,
      totalFaresEarned: newTotalFares,
    });

    get().saveGame();
  },
  setNPCCars: (npcCars) => set({ npcCars }),
  addScore: (points) => {
    set((state) => ({ score: state.score + points }));
    get().saveGame();
  },
  setMessage: (message) => set({ message }),
  setMapData: (mapData) => set({ mapData }),
  setCarStatus: (carPos, carAngle, carSpeed, carGear, isDrifting) => set({ carPos, carAngle, carSpeed, carGear, isDrifting }),
  addPassengerDistance: (dist) => set((state) => {
    let newMeterDistance = state.meterDistance + dist;
    let newFare = state.currentFare;
    // メーターのMAX到達距離 (走るとメーターが溜まりリセットされる)
    const METER_MAX = 25.0; 
    while (newMeterDistance >= METER_MAX) {
      newFare += 2.0; // メーターがMAXになったら上がる料金
      newMeterDistance -= METER_MAX;
    }
    return {
      passengerDistance: state.passengerDistance + dist,
      meterDistance: newMeterDistance,
      currentFare: newFare
    };
  }),
  
  toggleSettings: () => set((state) => ({ isSettingsOpen: !state.isSettingsOpen })),
  updateSettings: (settings) => {
    set((state) => ({ ...state, ...settings }));
    get().saveGame();
  },
  setFps: (fps) => set({ fps }),
  toggleCameraMode: () => {
    set((state) => {
      const next = state.cameraMode === 'TPS' ? 'FPS' : 'TPS';
      return { cameraMode: next };
    });
    get().saveGame();
  },
  setCameraMode: (cameraMode) => {
    set({ cameraMode });
    get().saveGame();
  },

  toggleGarage: () => set((state) => ({ isGarageOpen: !state.isGarageOpen })),
  buyUpgrade: (type) => {
    const state = get();
    const currentLvl = state.carUpgrades[type];
    if (type === 'spoiler' && currentLvl >= 3) return false;
    if (type !== 'spoiler' && currentLvl >= 5) return false;

    // アップグレード価格表 (アスファルト風)
    const costTable: Record<string, number[]> = {
      topSpeed: [0, 80, 180, 350, 600],
      acceleration: [0, 70, 160, 320, 550],
      handling: [0, 60, 140, 280, 500],
      nitro: [0, 90, 200, 400, 700],
      spoiler: [0, 100, 250, 500],
    };

    const cost = costTable[type][currentLvl] || 100;
    if (state.score < cost) return false;

    set((s) => ({
      score: s.score - cost,
      carUpgrades: {
        ...s.carUpgrades,
        [type]: currentLvl + 1,
      },
      message: `アップグレード成功！ ${type.toUpperCase()} が レベル ${currentLvl + 1} になりました！`,
    }));

    get().saveGame();
    return true;
  },
  buyCar: (model, price) => {
    const state = get();
    if (state.score < price) return false;
    if (state.ownedCars.includes(model)) return false;

    set((s) => ({
      score: s.score - price,
      ownedCars: [...s.ownedCars, model],
      carModel: model,
      message: `新車を購入しました！ (${model.toUpperCase()})`,
    }));

    get().saveGame();
    return true;
  },
  setCarModel: (model) => {
    set((state) => {
      if (state.ownedCars.includes(model)) {
        return { carModel: model };
      }
      return state;
    });
    get().saveGame();
  },
  setBodyColor: (color) => {
    set((state) => ({
      carUpgrades: { ...state.carUpgrades, bodyColor: color }
    }));
    get().saveGame();
  },
  setNeonColor: (neon) => {
    set((state) => ({
      carUpgrades: { ...state.carUpgrades, neonColor: neon }
    }));
    get().saveGame();
  },
  useNitro: (active) => {
    const state = get();
    if (active && state.nitroLeft > 5) {
      set({ isNitroActive: true });
    } else {
      set({ isNitroActive: false });
    }
  },
  updateNitroGauge: (delta) => set((state) => {
    if (state.isNitroActive) {
      // ニトロ消費 (ニトロレベルが高いほど長持ち)
      const drainRate = 35 / (1 + state.carUpgrades.nitro * 0.2);
      const newNitro = Math.max(0, state.nitroLeft - drainRate * delta);
      return {
        nitroLeft: newNitro,
        isNitroActive: newNitro > 0,
      };
    } else {
      // 自然回復 (ドリフト中などは早く溜まる)
      const chargeRate = state.isDrifting ? 25 : 8;
      return {
        nitroLeft: Math.min(100, state.nitroLeft + chargeRate * delta),
      };
    }
  }),

  // WAS Persistence Actions
  saveGame: () => {
    const s = get();
    const saved = saveWASData({
      score: s.score,
      ownedCars: s.ownedCars,
      carModel: s.carModel,
      carUpgrades: s.carUpgrades,
      settings: {
        showControls: s.showControls,
        enableShadows: s.enableShadows,
        ultraLowMode: s.ultraLowMode,
        soundVolume: s.soundVolume,
        bgmGenre: s.bgmGenre,
        cameraMode: s.cameraMode,
      },
      stats: {
        passengersDelivered: s.passengersDelivered,
        totalFaresEarned: s.totalFaresEarned,
      },
    });
    set({ lastSavedAt: saved.updatedAt });
  },

  resetGame: () => {
    clearWASData();
    const defaults = loadWASData();
    set({
      score: defaults.score,
      ownedCars: defaults.ownedCars,
      carModel: defaults.carModel,
      carUpgrades: defaults.carUpgrades,
      showControls: defaults.settings.showControls,
      enableShadows: defaults.settings.enableShadows,
      ultraLowMode: defaults.settings.ultraLowMode,
      soundVolume: defaults.settings.soundVolume,
      bgmGenre: defaults.settings.bgmGenre,
      cameraMode: defaults.settings.cameraMode,
      passengersDelivered: 0,
      totalFaresEarned: 0,
      lastSavedAt: Date.now(),
      message: 'セーブデータを初期化しました',
    });
  },

  loadGame: (externalData) => {
    const data = externalData || loadWASData();
    set((state) => ({
      score: data.score !== undefined ? data.score : state.score,
      ownedCars: (data.ownedCars as ('classic' | 'sport' | 'hyper')[]) || state.ownedCars,
      carModel: (data.carModel as 'classic' | 'sport' | 'hyper') || state.carModel,
      carUpgrades: data.carUpgrades ? { ...state.carUpgrades, ...data.carUpgrades } : state.carUpgrades,
      showControls: data.settings?.showControls !== undefined ? data.settings.showControls : state.showControls,
      enableShadows: data.settings?.enableShadows !== undefined ? data.settings.enableShadows : state.enableShadows,
      ultraLowMode: data.settings?.ultraLowMode !== undefined ? data.settings.ultraLowMode : state.ultraLowMode,
      soundVolume: data.settings?.soundVolume !== undefined ? data.settings.soundVolume : state.soundVolume,
      bgmGenre: data.settings?.bgmGenre || state.bgmGenre,
      cameraMode: data.settings?.cameraMode || state.cameraMode,
      passengersDelivered: data.stats?.passengersDelivered ?? state.passengersDelivered,
      totalFaresEarned: data.stats?.totalFaresEarned ?? state.totalFaresEarned,
      lastSavedAt: Date.now(),
      message: 'WASセーブデータを読み込みました',
    }));
  },
}));
