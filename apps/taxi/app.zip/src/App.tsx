import { GameScene } from './components/GameScene';
import { Minimap } from './components/Minimap';
import { SettingsMenu } from './components/SettingsMenu';
import { GarageMenu } from './components/GarageMenu';
import { useGameStore } from './store/gameStore';
import { useEffect } from 'react';
import { soundEngine } from './utils/audio';
import { notifyWASReady, WAS_APP_ID } from './utils/wasBridge';

export default function App() {
  const score = useGameStore(state => state.score);
  const message = useGameStore(state => state.message);
  const showControls = useGameStore(state => state.showControls);
  const hasPassenger = useGameStore(state => state.hasPassenger);
  const activePassenger = useGameStore(state => state.activePassenger);
  const toggleGarage = useGameStore(state => state.toggleGarage);
  const toggleSettings = useGameStore(state => state.toggleSettings);
  const cameraMode = useGameStore(state => state.cameraMode);
  const toggleCameraMode = useGameStore(state => state.toggleCameraMode);
  const currentFare = useGameStore(state => state.currentFare);
  const isSettingsOpen = useGameStore(state => state.isSettingsOpen);

  // 初回のユーザーインタラクションでAudioContextを開始 & Gキー / Cキーリスナー & WAS連携
  useEffect(() => {
    // WAS host notification
    notifyWASReady();

    const initAudio = () => {
      soundEngine.init();
      window.removeEventListener('keydown', initAudio);
      window.removeEventListener('mousedown', initAudio);
    };
    window.addEventListener('keydown', initAudio);
    window.addEventListener('mousedown', initAudio);

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'KeyG' && !e.repeat) {
        toggleGarage();
      }
      if (e.code === 'KeyC' && !e.repeat) {
        toggleCameraMode();
      }
    };
    window.addEventListener('keydown', handleKeyDown);

    // WAS (Web App Store) メッセージイベントリスナー
    const handleWASMessage = (event: MessageEvent) => {
      if (!event.data || typeof event.data !== 'object') return;
      const { type, appId, data } = event.data;
      if (appId && appId !== WAS_APP_ID) return;

      if (type === 'WAS_LOAD_DATA' || type === 'LOAD_DATA') {
        useGameStore.getState().loadGame(data);
      } else if (type === 'WAS_PAUSE') {
        if (!useGameStore.getState().isSettingsOpen) {
          useGameStore.getState().toggleSettings();
        }
      } else if (type === 'WAS_RESUME') {
        if (useGameStore.getState().isSettingsOpen) {
          useGameStore.getState().toggleSettings();
        }
      } else if (type === 'WAS_GET_DATA') {
        useGameStore.getState().saveGame();
      } else if (type === 'WAS_RESET') {
        useGameStore.getState().resetGame();
      }
    };
    window.addEventListener('message', handleWASMessage);

    // 終了前保存
    const handleBeforeUnload = () => {
      useGameStore.getState().saveGame();
    };
    window.addEventListener('beforeunload', handleBeforeUnload);

    // 定期オートセーブ (15秒ごと)
    const saveInterval = window.setInterval(() => {
      useGameStore.getState().saveGame();
    }, 15000);

    return () => {
      window.removeEventListener('keydown', initAudio);
      window.removeEventListener('mousedown', initAudio);
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('message', handleWASMessage);
      window.removeEventListener('beforeunload', handleBeforeUnload);
      clearInterval(saveInterval);
    };
  }, [toggleGarage, toggleCameraMode]);

  return (
    <div className="w-full h-screen relative bg-zinc-950 overflow-hidden font-sans select-none">
      <GameScene />
      
      {/* Top HUD Overlay (Asphalt Style) */}
      <div className="absolute inset-0 pointer-events-none z-10 font-[oblique] italic select-none">
        
        {/* Top Left: Pause & Stats */}
        <div className="absolute top-6 left-6 flex items-start gap-4">
          <button 
            onClick={toggleSettings}
            className="pointer-events-auto bg-zinc-950/80 text-white border-2 border-white/20 w-12 h-12 flex flex-col justify-center items-center gap-1 hover:bg-zinc-800 transition-colors shadow-lg cursor-pointer"
            title="設定 (ESC)"
          >
            <div className="flex gap-1">
              <div className="w-1.5 h-4 bg-white" />
              <div className="w-1.5 h-4 bg-white" />
            </div>
          </button>

          <div className="flex flex-col gap-1">
            <div className="bg-black/40 backdrop-blur-sm border-b-2 border-rose-600 px-3 py-1 flex justify-between items-center w-44">
              <span className="text-white font-bold text-lg">CASH</span>
              <span className="text-rose-400 font-black text-xl">${Math.floor(score)}</span>
            </div>
            <div className="bg-black/40 backdrop-blur-sm border-b-2 border-rose-600 px-3 py-1 flex justify-between items-center w-44">
              <span className="text-white font-bold text-lg">FARE</span>
              <span className="text-white font-black text-xl">{hasPassenger ? `$${Math.floor(currentFare)}` : '---'}</span>
            </div>
            
            <div className="mt-2 text-white text-base md:text-xl font-black flex items-center justify-between w-44">
              <span className="tracking-tighter">WAS: TAXI</span>
              <span className="text-[10px] text-emerald-400 bg-emerald-950/60 px-1.5 py-0.5 border border-emerald-500/40 rounded not-italic font-mono">
                SYNCED
              </span>
            </div>
            
            <div className="mt-2 pointer-events-auto flex gap-2">
              <button
                onClick={toggleGarage}
                className="bg-amber-500 hover:bg-amber-400 text-black px-4 py-1 font-black uppercase tracking-wider skew-x-[-10deg] border-2 border-transparent hover:border-white transition-all shadow-[0_0_15px_rgba(245,158,11,0.5)] cursor-pointer"
              >
                <span className="skew-x-[10deg] block">GARAGE [G]</span>
              </button>
              <button
                onClick={toggleCameraMode}
                className="bg-zinc-800 hover:bg-zinc-700 text-white px-4 py-1 font-black uppercase tracking-wider skew-x-[-10deg] border-2 border-transparent hover:border-white transition-all shadow-lg cursor-pointer"
              >
                <span className="skew-x-[10deg] block">{cameraMode} [C]</span>
              </button>
            </div>
          </div>
        </div>

        {/* Top Middle: Nitro Bar */}
        <div className="absolute top-4 left-1/2 -translate-x-1/2 w-72 md:w-96">
          <div className="w-full h-4 bg-black/60 skew-x-[-20deg] border-2 border-white/20 p-0.5 relative overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-yellow-400 to-yellow-200 transition-all duration-75"
              style={{ 
                width: `${useGameStore(state => state.nitroLeft)}%`,
                boxShadow: useGameStore(state => state.isNitroActive) ? '0 0 10px #fde047' : 'none'
              }}
            />
          </div>
          <div className="text-center text-xs font-black tracking-widest uppercase mt-1 text-yellow-400 drop-shadow-md">
            NITRO
          </div>
        </div>

        {/* Top Right: Speedometer & Timer */}
        <div className="absolute top-4 right-4 flex flex-col items-end">
          <div className="flex items-baseline gap-2">
            <div className="text-white font-bold text-lg tracking-wider mb-2">KM/H</div>
            <div 
              className={`text-6xl md:text-8xl font-black tracking-tighter shadow-black drop-shadow-[0_4px_4px_rgba(0,0,0,0.5)] ${
                useGameStore(state => state.isNitroActive) ? 'text-cyan-300' : 'text-white'
              }`}
            >
              {Math.round(useGameStore(state => state.carSpeed) * 2.5)}
            </div>
          </div>
          <div className="bg-rose-600 text-white font-black text-xl md:text-2xl px-6 py-1 tracking-wider mt-1 skew-x-[-15deg] shadow-lg flex items-center gap-2 border-r-4 border-white">
            <div className="skew-x-[15deg] block">
              ⏱ {String(Math.floor(score / 60)).padStart(2, '0')}:{String(score % 60).padStart(2, '0')}.000
            </div>
          </div>
        </div>

        {/* Right Middle: Action popups */}
        <div className="absolute top-1/2 right-0 -translate-y-1/2 flex flex-col gap-2 items-end">
          {useGameStore(state => state.isDrifting) && (
            <div className="bg-black text-white px-8 py-2 font-black text-xl md:text-2xl tracking-widest uppercase border-r-4 border-cyan-400 skew-x-[-15deg] translate-x-4 shadow-[0_0_15px_rgba(34,211,238,0.3)] animate-pulse">
              <span className="skew-x-[15deg] block text-cyan-400">DRIFTING !</span>
            </div>
          )}
          {hasPassenger && activePassenger && (
            <div className="bg-black text-white px-8 py-2 font-black text-lg tracking-widest uppercase border-r-4 border-amber-400 skew-x-[-15deg] translate-x-4 shadow-[0_0_15px_rgba(251,191,36,0.3)] mt-4">
              <span className="skew-x-[15deg] block text-amber-400">TARGET: {activePassenger.name}</span>
            </div>
          )}
        </div>

        {/* Center Top Message */}
        <div className="absolute top-8 left-1/2 -translate-x-1/2 flex flex-col items-center">
          {message && (
            <div className="text-white font-black text-lg md:text-xl bg-black/60 px-6 py-2 skew-x-[-15deg] border-b-2 border-white text-center">
              <span className="skew-x-[15deg] block drop-shadow-md">{message}</span>
            </div>
          )}
        </div>

      </div>

      {/* 左下: コントロール説明 (Asphalt Style) */}
      {showControls && (
        <div className="absolute bottom-6 left-6 pointer-events-none z-10 transition-opacity flex flex-col gap-2 text-white font-[oblique] italic">
          <div className="text-xs md:text-sm font-bold bg-black/60 px-4 py-1.5 skew-x-[-10deg] border-l-4 border-amber-400">
            <span className="skew-x-[10deg] block">[W][A][S][D] DRIVE</span>
          </div>
          <div className="text-xs md:text-sm font-bold bg-black/60 px-4 py-1.5 skew-x-[-10deg] border-l-4 border-rose-500">
            <span className="skew-x-[10deg] block">[SPACE] DRIFT</span>
          </div>
          <div className="text-xs md:text-sm font-bold bg-black/60 px-4 py-1.5 skew-x-[-10deg] border-l-4 border-cyan-400">
            <span className="skew-x-[10deg] block">[N] or [E] NITRO</span>
          </div>
          <div className="text-xs md:text-sm font-bold bg-black/60 px-4 py-1.5 skew-x-[-10deg] border-l-4 border-zinc-400">
            <span className="skew-x-[10deg] block">[↑][↓] GEAR SHIFT</span>
          </div>
        </div>
      )}

      <Minimap />
      <GarageMenu />
      <SettingsMenu />
    </div>
  );
}
