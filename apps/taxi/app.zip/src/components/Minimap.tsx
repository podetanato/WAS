import { useEffect, useRef } from 'react';
import { useGameStore } from '../store/gameStore';
import { CELL_SIZE, GRID_WIDTH, GRID_HEIGHT, CellType } from '../utils/mapLogic';

export function Minimap() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;

    const renderMinimap = () => {
      const state = useGameStore.getState();
      const carPos = state.carPos;
      const carAngle = state.carAngle;
      const passengers = state.passengers;
      const activePassenger = state.activePassenger;
      const hasPass = state.hasPassenger;
      const npcCars = state.npcCars;
      const data = state.mapData;

      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      // 背景
      ctx.fillStyle = '#111318';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      if (!data) {
        animationFrameId = requestAnimationFrame(renderMinimap);
        return;
      }

      // 描画スケール
      const scale = 0.45;
      const cx = canvas.width / 2;
      const cy = canvas.height / 2;

      ctx.save();
      ctx.translate(cx, cy);
      ctx.scale(scale, scale);
      ctx.translate(-carPos.x, -carPos.z);

      const halfW = Math.floor(GRID_WIDTH / 2);
      const halfH = Math.floor(GRID_HEIGHT / 2);

      // 周辺の道路・建物のみ描画して軽量化
      for (let z = 0; z < GRID_HEIGHT; z++) {
        for (let x = 0; x < GRID_WIDTH; x++) {
          const posX = (x - halfW) * CELL_SIZE;
          const posZ = (z - halfH) * CELL_SIZE;

          if (Math.abs(posX - carPos.x) < 250 && Math.abs(posZ - carPos.z) < 250) {
            const cell = data.grid[z][x];
            if (cell === CellType.ROAD) {
              ctx.fillStyle = '#374151';
            } else if (cell === CellType.BUILDING) {
              ctx.fillStyle = '#1f2937';
            } else if (cell === CellType.PARK) {
              ctx.fillStyle = '#065f46';
            }
            ctx.fillRect(posX - CELL_SIZE / 2, posZ - CELL_SIZE / 2, CELL_SIZE, CELL_SIZE);
          }
        }
      }

      // NPC車両の描画 (白い小さな矩形/ドット)
      npcCars.forEach(npc => {
        if (Math.abs(npc.pos.x - carPos.x) < 250 && Math.abs(npc.pos.z - carPos.z) < 250) {
          ctx.save();
          ctx.translate(npc.pos.x, npc.pos.z);
          ctx.rotate(npc.angle);
          ctx.fillStyle = '#e2e8f0';
          ctx.fillRect(-2, -4, 4, 8);
          ctx.restore();
        }
      });

      // 5人の乗客の描画 (青いパルスアイコン)
      if (!hasPass) {
        passengers.forEach((p, idx) => {
          ctx.fillStyle = '#3b82f6';
          ctx.beginPath();
          ctx.arc(p.pos.x, p.pos.z, 7, 0, Math.PI * 2);
          ctx.fill();
          
          // パルス
          ctx.strokeStyle = '#60a5fa';
          ctx.lineWidth = 2;
          ctx.beginPath();
          const pulse = ((Date.now() + idx * 200) % 1000) / 1000;
          ctx.arc(p.pos.x, p.pos.z, 7 + pulse * 8, 0, Math.PI * 2);
          ctx.stroke();
        });
      }

      // 目的地の描画 (乗車中のみ)
      if (hasPass && activePassenger) {
        const dest = activePassenger.destinationPos;
        ctx.fillStyle = '#10b981';
        ctx.beginPath();
        ctx.arc(dest.x, dest.z, 9, 0, Math.PI * 2);
        ctx.fill();
        
        ctx.strokeStyle = '#34d399';
        ctx.lineWidth = 3;
        ctx.beginPath();
        const pulse = (Date.now() % 1000) / 1000;
        ctx.arc(dest.x, dest.z, 9 + pulse * 12, 0, Math.PI * 2);
        ctx.stroke();
      }

      ctx.restore();

      // プレイヤー（自車）の描画（常に中央）
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(carAngle);
      
      ctx.fillStyle = '#fbbf24';
      ctx.beginPath();
      ctx.moveTo(0, 9); // 前方
      ctx.lineTo(5, -7);
      ctx.lineTo(-5, -7);
      ctx.closePath();
      ctx.fill();
      
      ctx.strokeStyle = '#000000';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      ctx.restore();

      animationFrameId = requestAnimationFrame(renderMinimap);
    };

    renderMinimap();

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <div className="absolute bottom-6 right-6 z-10 rounded-full overflow-hidden border-4 border-zinc-800 shadow-2xl bg-zinc-950 w-48 h-48 pointer-events-none">
      <canvas ref={canvasRef} width={192} height={192} className="w-full h-full" />
      <div className="absolute top-1.5 left-1/2 -translate-x-1/2 text-[10px] font-black text-amber-500/80 tracking-widest">N</div>
      <div className="absolute bottom-1.5 left-1/2 -translate-x-1/2 text-[9px] font-bold text-zinc-500 tracking-wider">GPS RADAR</div>
    </div>
  );
}
