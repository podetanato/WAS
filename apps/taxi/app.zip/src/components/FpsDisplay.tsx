import { useGameStore } from '../store/gameStore';
import { Activity, Cpu } from 'lucide-react';

export function FpsDisplay() {
  const fps = useGameStore(state => state.fps);
  const ultraLowMode = useGameStore(state => state.ultraLowMode);

  // FPSに応じた色分け
  let fpsColorClass = 'text-emerald-400 border-emerald-500/40 bg-emerald-950/40';
  let dotColor = 'bg-emerald-400';
  if (fps < 30) {
    fpsColorClass = 'text-rose-400 border-rose-500/40 bg-rose-950/40';
    dotColor = 'bg-rose-500';
  } else if (fps < 50) {
    fpsColorClass = 'text-amber-400 border-amber-500/40 bg-amber-950/40';
    dotColor = 'bg-amber-400';
  }

  // 1フレームの描画時間(ms)
  const frameTimeMs = fps > 0 ? (1000 / fps).toFixed(1) : '0.0';

  return (
    <div className="flex items-center gap-2 pointer-events-auto">
      {/* ウルトラ低負荷モードバッジ */}
      {ultraLowMode && (
        <div className="bg-cyan-950/80 backdrop-blur border border-cyan-500/40 px-2.5 py-1 rounded-xl flex items-center gap-1.5 shadow-lg shadow-cyan-950/30 animate-pulse">
          <Cpu className="w-3.5 h-3.5 text-cyan-400" />
          <span className="text-[10px] font-black text-cyan-300 uppercase tracking-wider">
            ULTRA LOW
          </span>
        </div>
      )}

      {/* FPSメーター */}
      <div className={`backdrop-blur-md px-3 py-1.5 rounded-xl border flex items-center gap-2 shadow-xl ${fpsColorClass}`}>
        <div className="flex items-center gap-1.5">
          <span className={`w-2 h-2 rounded-full ${dotColor} animate-ping`} style={{ animationDuration: '2s' }} />
          <span className="font-mono font-black text-sm tracking-tight">
            {fps} <span className="text-[10px] font-bold uppercase">FPS</span>
          </span>
        </div>
        <div className="w-[1px] h-3 bg-zinc-700/60" />
        <span className="text-[10px] font-mono text-zinc-400">
          {frameTimeMs}ms
        </span>
      </div>
    </div>
  );
}
