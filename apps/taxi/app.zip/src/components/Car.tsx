import { useRef, useMemo } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';
import { useKeyboard } from '../hooks/useKeyboard';
import { useGameStore } from '../store/gameStore';
import { CELL_SIZE, GRID_WIDTH, GRID_HEIGHT, CellType } from '../utils/mapLogic';
import { soundEngine } from '../utils/audio';

const BRAKING = 38.0;
const FRICTION = 9.0;

interface SmokeParticle {
  pos: THREE.Vector3;
  opacity: number;
  scale: number;
  color?: string;
}

const HALF_W = Math.floor(GRID_WIDTH / 2);
const HALF_H = Math.floor(GRID_HEIGHT / 2);
const CAR_RADIUS = 1.35; // 車両の衝突球半径
const BUILDING_HALF_SIZE = 8.5; // 建物の半幅 (CELL_SIZE=20 のうち道路マージンを考慮した実際のブロックサイズ)

export function Car() {
  const carRef = useRef<THREE.Group>(null);
  const keys = useKeyboard();
  const { camera } = useThree();
  
  const speed = useRef(0);
  const angle = useRef(0); // 車体の向き (ラジアン)
  const velocity = useRef(new THREE.Vector2(0, 0)); // 実際の移動速度ベクトル (X, Z)
  const isDrifting = useRef(false);
  const prevCollisionTime = useRef(0);
  
  const gearRef = useRef(1); // ギア: -1(R), 0(N), 1, 2, 3, 4, 5
  const prevUp = useRef(false);
  const prevDown = useRef(false);

  // タイヤスモーク & ニトロ炎用パーティクル
  const smokeParticles = useRef<SmokeParticle[]>([]);
  const smokeMeshRef = useRef<THREE.InstancedMesh>(null);
  const nitroParticles = useRef<SmokeParticle[]>([]);
  const nitroMeshRef = useRef<THREE.InstancedMesh>(null);

  const hasPassenger = useGameStore(state => state.hasPassenger);
  const activePassenger = useGameStore(state => state.activePassenger);
  const passengers = useGameStore(state => state.passengers);
  const passengerDistance = useGameStore(state => state.passengerDistance);
  const isSettingsOpen = useGameStore(state => state.isSettingsOpen);
  const isGarageOpen = useGameStore(state => state.isGarageOpen);
  const cameraMode = useGameStore(state => state.cameraMode);
  
  const carUpgrades = useGameStore(state => state.carUpgrades);
  const isNitroActive = useGameStore(state => state.isNitroActive);
  const useNitro = useGameStore(state => state.useNitro);
  const updateNitroGauge = useGameStore(state => state.updateNitroGauge);
  const carModel = useGameStore(state => state.carModel);

  const pickUpPassenger = useGameStore(state => state.pickUpPassenger);
  const dropOffPassenger = useGameStore(state => state.dropOffPassenger);
  const setMessage = useGameStore(state => state.setMessage);
  const mapData = useGameStore(state => state.mapData);
  const setCarStatus = useGameStore(state => state.setCarStatus);
  const addPassengerDistance = useGameStore(state => state.addPassengerDistance);

  useFrame((_, delta) => {
    if (!carRef.current) return;
    
    // 設定画面やガレージが開いているときは操作無効
    const k = (isSettingsOpen || isGarageOpen) ? {} : keys.current;

    // ニトロゲージの更新
    updateNitroGauge(delta);

    // ニトロキー (KeyN または KeyE)
    const nitroKey = !!(k['KeyN'] || k['KeyE']);
    useNitro(nitroKey);
    soundEngine.updateNitro(isNitroActive);
    
    // 1. シフトチェンジ (エッジ検出)
    const isUp = !!k['ArrowUp'];
    const isDown = !!k['ArrowDown'];
    
    if (isUp && !prevUp.current) {
      gearRef.current = Math.min(5, gearRef.current + 1);
    }
    if (isDown && !prevDown.current) {
      gearRef.current = Math.max(-1, gearRef.current - 1);
    }
    prevUp.current = isUp;
    prevDown.current = isDown;

    // アップグレード補正値
    const topSpeedMult = 1.0 + (carUpgrades.topSpeed - 1) * 0.15;
    const accelMult = 1.0 + (carUpgrades.acceleration - 1) * 0.3;
    const handlingMult = 1.0 + (carUpgrades.handling - 1) * 0.12;
    const nitroBoostPower = isNitroActive ? (1.3 + carUpgrades.nitro * 0.18) : 1.0;

    // ギアごとのスペック { 最高速度, 加速度 }
    const gearSpecs: Record<number, { max: number, acc: number }> = {
      [-1]: { max: 15 * topSpeedMult, acc: 16 * accelMult },
       0:   { max: 0,  acc: 0 },
       1:   { max: 16 * topSpeedMult, acc: 28 * accelMult },
       2:   { max: 26 * topSpeedMult, acc: 20 * accelMult },
       3:   { max: 38 * topSpeedMult, acc: 14 * accelMult },
       4:   { max: 50 * topSpeedMult, acc: 9 * accelMult },
       5:   { max: 68 * topSpeedMult, acc: 6 * accelMult },
    };
    const currentSpec = gearSpecs[gearRef.current];

    // ドリフトキー判定 (Space)
    const handbrake = !!(k['Space']);
    
    // 2. アクセル・ブレーキ処理
    let throttle = false;
    if (k['KeyW']) {
      throttle = true;
      const effectiveAcc = currentSpec.acc * (isNitroActive ? (1.5 + carUpgrades.nitro * 0.2) : 1.0);
      const effectiveMax = currentSpec.max * nitroBoostPower;

      if (gearRef.current > 0) {
        speed.current += effectiveAcc * delta;
        if (speed.current > effectiveMax) {
          speed.current -= effectiveAcc * 2 * delta;
        }
      } else if (gearRef.current === -1) {
        speed.current -= effectiveAcc * delta;
        if (speed.current < -effectiveMax) {
          speed.current += effectiveAcc * 2 * delta;
        }
      }
    } else if (k['KeyS']) {
      // ブレーキ
      if (speed.current > 0) {
        speed.current = Math.max(0, speed.current - BRAKING * delta);
      } else if (speed.current < 0) {
        speed.current = Math.min(0, speed.current + BRAKING * delta);
      }
    } else {
      // 自然摩擦 / エンジンブレーキ
      const friction = gearRef.current !== 0 ? FRICTION * 1.5 : FRICTION * 0.5;
      if (speed.current > 0) {
        speed.current = Math.max(0, speed.current - friction * delta);
      } else if (speed.current < 0) {
        speed.current = Math.min(0, speed.current + friction * delta);
      }
    }

    // ハンドブレーキによる減速
    if (handbrake && !throttle) {
      if (speed.current > 0) {
        speed.current = Math.max(0, speed.current - (BRAKING * 0.7) * delta);
      } else if (speed.current < 0) {
        speed.current = Math.min(0, speed.current + (BRAKING * 0.7) * delta);
      }
    }

    // 3. ステアリングとドリフト物理
    const absSpeed = Math.abs(speed.current);
    const isHighSpeed = absSpeed > 10;
    const isTurning = !!(k['ArrowLeft'] || k['KeyA'] || k['ArrowRight'] || k['KeyD']);
    
    // ドリフトトリガー判定
    const drifting = (handbrake && absSpeed > 6) || (isHighSpeed && isTurning && handbrake);
    isDrifting.current = drifting;

    const baseTurnSpeed = drifting ? (2.5 * handlingMult) : (1.65 * handlingMult);

    if (absSpeed > 0.1) {
      const turnDir = speed.current >= 0 ? 1 : -1;
      if (k['ArrowLeft'] || k['KeyA']) {
        angle.current += baseTurnSpeed * turnDir * delta;
      }
      if (k['ArrowRight'] || k['KeyD']) {
        angle.current -= baseTurnSpeed * turnDir * delta;
      }
    }

    // 車体の前方向ベクトル
    const forwardX = Math.sin(angle.current);
    const forwardZ = Math.cos(angle.current);

    // 速度ベクトルの補間（ドリフト時は横滑り慣性を持たせる）
    const targetVx = forwardX * speed.current;
    const targetVz = forwardZ * speed.current;

    const grip = drifting ? (2.4 + carUpgrades.handling * 0.2) : (8.2 + carUpgrades.handling * 0.4);
    velocity.current.x += (targetVx - velocity.current.x) * grip * delta;
    velocity.current.y += (targetVz - velocity.current.y) * grip * delta;

    let moveX = velocity.current.x * delta;
    let moveZ = velocity.current.y * delta;

    let curPosX = carRef.current.position.x + moveX;
    let curPosZ = carRef.current.position.z + moveZ;

    // 4. 自然なスライディング当たり判定 (Sliding Collision Response & Penetration Resolution)
    if (mapData) {
      const centerGridX = Math.floor(curPosX / CELL_SIZE + HALF_W);
      const centerGridZ = Math.floor(curPosZ / CELL_SIZE + HALF_H);

      // 周囲 3x3 のセルをチェック
      for (let gz = centerGridZ - 1; gz <= centerGridZ + 1; gz++) {
        for (let gx = centerGridX - 1; gx <= centerGridX + 1; gx++) {
          if (gx < 0 || gx >= GRID_WIDTH || gz < 0 || gz >= GRID_HEIGHT) continue;
          
          if (mapData.grid[gz][gx] === CellType.BUILDING) {
            const bCenterX = (gx - HALF_W) * CELL_SIZE;
            const bCenterZ = (gz - HALF_H) * CELL_SIZE;

            const minX = bCenterX - BUILDING_HALF_SIZE;
            const maxX = bCenterX + BUILDING_HALF_SIZE;
            const minZ = bCenterZ - BUILDING_HALF_SIZE;
            const maxZ = bCenterZ + BUILDING_HALF_SIZE;

            // 車体中心から建物矩形への最近接点 (Clamping)
            const nearestX = Math.max(minX, Math.min(maxX, curPosX));
            const nearestZ = Math.max(minZ, Math.min(maxZ, curPosZ));

            const diffX = curPosX - nearestX;
            const diffZ = curPosZ - nearestZ;
            const distSq = diffX * diffX + diffZ * diffZ;

            if (distSq < CAR_RADIUS * CAR_RADIUS) {
              const dist = Math.sqrt(distSq);
              let nx = 0;
              let nz = 0;
              let overlap = 0;

              if (dist > 0.001) {
                // 外側からの衝突
                nx = diffX / dist;
                nz = diffZ / dist;
                overlap = CAR_RADIUS - dist;
              } else {
                // 万一中心が矩形内部に入り込んだ場合: 最も近い面へ押し戻し
                const distLeft = curPosX - minX;
                const distRight = maxX - curPosX;
                const distTop = curPosZ - minZ;
                const distBottom = maxZ - curPosZ;
                const minDist = Math.min(distLeft, distRight, distTop, distBottom);

                if (minDist === distLeft) { nx = -1; nz = 0; overlap = CAR_RADIUS + distLeft; }
                else if (minDist === distRight) { nx = 1; nz = 0; overlap = CAR_RADIUS + distRight; }
                else if (minDist === distTop) { nx = 0; nz = -1; overlap = CAR_RADIUS + distTop; }
                else { nx = 0; nz = 1; overlap = CAR_RADIUS + distBottom; }
              }

              // 1. 位置の押し戻し (貫通を完全防止)
              curPosX += nx * overlap;
              curPosZ += nz * overlap;

              // 2. 速度の法線成分・接線成分の分解
              const currentVx = velocity.current.x;
              const currentVz = velocity.current.y;
              const normalVel = currentVx * nx + currentVz * nz;

              // 壁に向かって突進している場合 (normalVel < 0)
              if (normalVel < 0) {
                // 法線成分を打ち消す (壁と直交する運動をゼロにしてスライドさせる)
                velocity.current.x -= normalVel * nx;
                velocity.current.y -= normalVel * nz;

                // 壁面摩擦 (接線方向の速度を適度に減速して自然なスライディングを表現)
                velocity.current.x *= 0.90;
                velocity.current.y *= 0.90;

                // 正面衝突 vs 側面擦り の判定
                const impactStrength = Math.abs(normalVel);
                const now = Date.now();

                if (impactStrength > 7.0 && now - prevCollisionTime.current > 400) {
                  // 正面から激突: 衝突音 & スピード大幅減衰
                  soundEngine.playCollision();
                  prevCollisionTime.current = now;
                  speed.current *= 0.35;
                } else {
                  // 側面を擦った場合: 接線速度に合わせてスピードを維持
                  const remainingSpeed = Math.hypot(velocity.current.x, velocity.current.y);
                  speed.current = Math.sign(speed.current) * remainingSpeed;
                }
              }
            }
          }
        }
      }

      // マップ外枠境界クランプ (最外周の道路 ±400m もスムーズに走行可能)
      const maxMapBound = HALF_W * CELL_SIZE + CELL_SIZE * 0.45;
      curPosX = Math.max(-maxMapBound, Math.min(maxMapBound, curPosX));
      curPosZ = Math.max(-maxMapBound, Math.min(maxMapBound, curPosZ));
    }

    carRef.current.position.x = curPosX;
    carRef.current.position.z = curPosZ;
    carRef.current.rotation.y = angle.current;

    // 走行距離を加算
    if (hasPassenger) {
      const dist = Math.hypot(moveX, moveZ);
      addPassengerDistance(dist);
    }

    // 5. サウンド更新
    let rpm = 0;
    if (gearRef.current === 0) {
      rpm = throttle ? 1.0 : 0.2;
    } else {
      const ratio = absSpeed / (currentSpec.max || 1);
      rpm = 0.2 + (ratio * 0.8) + (isNitroActive ? 0.2 : 0);
    }
    soundEngine.updateEngine(rpm);
    soundEngine.updateDrift(drifting && absSpeed > 6, drifting ? 1.0 : 0);

    // 6. タイヤスモーク & ニトロエフェクト
    if (drifting && absSpeed > 6) {
      const rearOffset = 1.6;
      const rx = carRef.current.position.x - Math.sin(angle.current) * rearOffset;
      const rz = carRef.current.position.z - Math.cos(angle.current) * rearOffset;

      if (smokeParticles.current.length < 30) {
        smokeParticles.current.push({
          pos: new THREE.Vector3(rx + (Math.random() - 0.5) * 1.5, 0.3, rz + (Math.random() - 0.5) * 1.5),
          opacity: 0.6,
          scale: 0.6 + Math.random() * 0.5,
        });
      }
    }

    // ニトロ時のバックファイア（青い炎）
    if (isNitroActive) {
      const rearOffset = 2.4;
      const rx = carRef.current.position.x - Math.sin(angle.current) * rearOffset;
      const rz = carRef.current.position.z - Math.cos(angle.current) * rearOffset;

      if (nitroParticles.current.length < 25) {
        nitroParticles.current.push({
          pos: new THREE.Vector3(rx + (Math.random() - 0.5) * 0.6, 0.4, rz + (Math.random() - 0.5) * 0.6),
          opacity: 0.9,
          scale: 0.4 + Math.random() * 0.4,
        });
      }
    }

    // スモークの更新
    const dummy = new THREE.Object3D();
    for (let i = smokeParticles.current.length - 1; i >= 0; i--) {
      const p = smokeParticles.current[i];
      p.pos.y += delta * 1.5;
      p.scale += delta * 2.0;
      p.opacity -= delta * 1.8;

      if (p.opacity <= 0) {
        smokeParticles.current.splice(i, 1);
      }
    }

    if (smokeMeshRef.current) {
      smokeParticles.current.forEach((p, i) => {
        dummy.position.copy(p.pos);
        dummy.scale.set(p.scale, p.scale, p.scale);
        dummy.updateMatrix();
        smokeMeshRef.current!.setMatrixAt(i, dummy.matrix);
      });
      smokeMeshRef.current.count = smokeParticles.current.length;
      smokeMeshRef.current.instanceMatrix.needsUpdate = true;
    }

    // ニトロパーティクルの更新
    for (let i = nitroParticles.current.length - 1; i >= 0; i--) {
      const p = nitroParticles.current[i];
      p.pos.y += delta * 0.6;
      p.scale += delta * 1.5;
      p.opacity -= delta * 3.5;

      if (p.opacity <= 0) {
        nitroParticles.current.splice(i, 1);
      }
    }

    if (nitroMeshRef.current) {
      nitroParticles.current.forEach((p, i) => {
        dummy.position.copy(p.pos);
        dummy.scale.set(p.scale, p.scale, p.scale);
        dummy.updateMatrix();
        nitroMeshRef.current!.setMatrixAt(i, dummy.matrix);
      });
      nitroMeshRef.current.count = nitroParticles.current.length;
      nitroMeshRef.current.instanceMatrix.needsUpdate = true;
    }

    // 7. カメラシステム (TPS vs FPS視点の切り替え)
    const carPos = carRef.current.position.clone();

    // カメラの上方向ベクトルを常にY軸正(0, 1, 0)に固定（反転や傾き防止）
    camera.up.set(0, 1, 0);

    if (cameraMode === 'FPS') {
      // --- FPS (一人称・運転席コクピット視点) ---
      // 運転席（右ハンドル仕様: X=0.48m, 高さ Y=1.65m, 前後 Z=0.35m）
      const driverSeatOffset = new THREE.Vector3(0.48, 1.65, 0.35);
      driverSeatOffset.applyAxisAngle(new THREE.Vector3(0, 1, 0), angle.current);
      
      const fpsCameraPos = carPos.clone().add(driverSeatOffset);

      // ドリフトやニトロ時の微小なカメラシェイク
      if (drifting) {
        fpsCameraPos.y += (Math.random() - 0.5) * 0.03;
      }
      if (isNitroActive) {
        fpsCameraPos.x += (Math.random() - 0.5) * 0.04;
        fpsCameraPos.z += (Math.random() - 0.5) * 0.04;
      }

      // 遅延なくカメラ位置を即時同期（FPSの車体とのズレをなくす）
      camera.position.copy(fpsCameraPos);

      // 注視点: 車両前方 30m
      const lookDist = 30.0;
      const lookAtPos = fpsCameraPos.clone().add(new THREE.Vector3(
        Math.sin(angle.current) * lookDist,
        -0.12, // 自然なアイレベルで見通しの良い前方視界
        Math.cos(angle.current) * lookDist
      ));
      camera.lookAt(lookAtPos);
    } else {
      // --- TPS (三人称チェイスカメラ) ---
      const cameraDistance = isNitroActive ? 18.5 : 16.0;
      const cameraHeight = isNitroActive ? 6.5 : 7.0;

      const cameraOffset = new THREE.Vector3(
        -Math.sin(angle.current) * cameraDistance,
        cameraHeight,
        -Math.cos(angle.current) * cameraDistance
      );
      
      camera.position.lerp(carPos.clone().add(cameraOffset), isNitroActive ? 0.35 : 0.28);
      
      const lookAtPos = carPos.clone().add(new THREE.Vector3(
        Math.sin(angle.current) * 18,
        1.0,
        Math.cos(angle.current) * 18
      ));
      camera.lookAt(lookAtPos);
    }

    // 8. 状態を同期
    setCarStatus(carRef.current.position.clone(), angle.current, absSpeed, gearRef.current, drifting);

    // 9. 5人の乗客との判定
    if (!hasPassenger && passengers.length > 0) {
      let nearestPassenger = null;
      let minDistance = Infinity;

      for (const p of passengers) {
        const d = carPos.distanceTo(p.pos);
        if (d < minDistance) {
          minDistance = d;
          nearestPassenger = p;
        }
      }

      if (nearestPassenger && minDistance < 6) {
        if (absSpeed < 2.5) {
          soundEngine.playPiron();
          pickUpPassenger(nearestPassenger);
        } else {
          setMessage(`${nearestPassenger.name}: 止まって乗せて！`);
        }
      }
    }

    // 10. 目的地判定
    if (hasPassenger && activePassenger) {
      const destDist = carPos.distanceTo(activePassenger.destinationPos);
      if (destDist < 8) {
        if (absSpeed < 2.5) {
          soundEngine.playPiron();
          dropOffPassenger();
        } else {
          setMessage('目的地到着！ 停車(速度0)してください！');
        }
      }
    }
  });

  // マテリアルのメモ化
  const bodyMaterial = useMemo(() => new THREE.MeshPhysicalMaterial({
    color: carUpgrades.bodyColor,
    metalness: 0.6,
    roughness: 0.15,
    clearcoat: 1.0,
    clearcoatRoughness: 0.1,
  }), [carUpgrades.bodyColor]);

  const glassMaterial = useMemo(() => new THREE.MeshPhysicalMaterial({
    color: '#09090b',
    metalness: 0.9,
    roughness: 0.1,
    transmission: 0.7,
    thickness: 0.5,
  }), []);

  const tireMaterial = useMemo(() => new THREE.MeshStandardMaterial({
    color: '#18181b',
    roughness: 0.9,
  }), []);

  const spoilerMat = useMemo(() => new THREE.MeshStandardMaterial({
    color: '#0f172a',
    roughness: 0.3,
    metalness: 0.8,
  }), []);

  const interiorMat = useMemo(() => new THREE.MeshStandardMaterial({
    color: '#18181b',
    roughness: 0.8,
  }), []);

  return (
    <>
      <group ref={carRef} position={[0, 1, 0]}>
        {carModel === 'classic' && (
          <group>
            {/* 車体ベース */}
            <mesh material={bodyMaterial} position={[0, 0.5, 0]} castShadow receiveShadow>
              <boxGeometry args={[2.2, 1.0, 4.8]} />
            </mesh>
            {/* キャビン (ガラス部分) */}
            <mesh material={glassMaterial} position={[0, 1.4, -0.2]} castShadow receiveShadow>
              <boxGeometry args={[1.9, 0.8, 2.4]} />
            </mesh>
            {/* ルーフサイン (TAXI) */}
            <mesh position={[0, 1.9, -0.2]} castShadow>
              <boxGeometry args={[0.9, 0.25, 0.4]} />
              <meshStandardMaterial color="#ffffff" emissive="#ffffff" emissiveIntensity={0.6} />
            </mesh>
          </group>
        )}
        
        {carModel === 'sport' && (
          <group>
            <mesh material={bodyMaterial} position={[0, 0.4, 0]} castShadow receiveShadow>
              <boxGeometry args={[2.3, 0.8, 4.9]} />
            </mesh>
            <mesh material={bodyMaterial} position={[0, 0.5, -0.6]} rotation={[0, 0, Math.PI / 2]} castShadow receiveShadow>
              <cylinderGeometry args={[1.1, 1.1, 4.6, 8, 1, false, 0, Math.PI]} />
            </mesh>
            <mesh material={glassMaterial} position={[0, 1.05, -0.1]} rotation={[0, 0, Math.PI / 2]} castShadow receiveShadow>
              <cylinderGeometry args={[0.9, 1.0, 2.6, 8, 1, false, 0, Math.PI]} />
            </mesh>
          </group>
        )}

        {carModel === 'hyper' && (
          <group>
            <mesh material={bodyMaterial} position={[0, 0.35, 0]} castShadow receiveShadow>
              <boxGeometry args={[2.4, 0.7, 5.0]} />
            </mesh>
            {/* 鋭角なフロントノーズ */}
            <mesh material={bodyMaterial} position={[0, 0.35, 2.5]} rotation={[Math.PI / 2, Math.PI / 4, 0]} castShadow receiveShadow>
              <cylinderGeometry args={[0.0, 1.2, 0.8, 4, 1]} />
            </mesh>
            <mesh material={glassMaterial} position={[0, 0.9, -0.2]} rotation={[0, 0, Math.PI / 2]} castShadow receiveShadow>
              <cylinderGeometry args={[0.8, 0.9, 2.2, 4, 1, false, 0, Math.PI]} />
            </mesh>
          </group>
        )}

        {/* コクピット内装・ダッシュボード (FPS視点時に美しく映える) */}
        <group position={[0, 1.05, 0.6]}>
          {/* ダッシュボード */}
          <mesh material={interiorMat} position={[0, 0.05, 0]}>
            <boxGeometry args={[1.75, 0.35, 0.6]} />
          </mesh>
          {/* ステアリングホイール (右ハンドル) */}
          <mesh material={interiorMat} position={[0.48, 0.2, -0.15]} rotation={[0.4, 0, 0]}>
            <torusGeometry args={[0.18, 0.03, 8, 16]} />
          </mesh>
          {/* スピードメーターパネル */}
          <mesh position={[0.48, 0.22, 0.05]} rotation={[-0.3, 0, 0]}>
            <planeGeometry args={[0.25, 0.12]} />
            <meshBasicMaterial color="#38bdf8" />
          </mesh>
        </group>

        {/* エアロスポイラー (改造パーツ) */}
        {carUpgrades.spoiler === 1 && (
          <mesh material={spoilerMat} position={[0, 1.1, -2.3]} castShadow>
            <boxGeometry args={[2.1, 0.08, 0.4]} />
          </mesh>
        )}
        {carUpgrades.spoiler === 2 && (
          <group position={[0, 1.3, -2.2]}>
            <mesh material={spoilerMat} position={[0, 0.35, 0]} castShadow>
              <boxGeometry args={[2.4, 0.08, 0.5]} />
            </mesh>
            <mesh material={spoilerMat} position={[0.8, 0.15, 0]} castShadow>
              <boxGeometry args={[0.08, 0.35, 0.3]} />
            </mesh>
            <mesh material={spoilerMat} position={[-0.8, 0.15, 0]} castShadow>
              <boxGeometry args={[0.08, 0.35, 0.3]} />
            </mesh>
          </group>
        )}
        {carUpgrades.spoiler === 3 && (
          <group position={[0, 1.45, -2.2]}>
            <mesh position={[0, 0.4, 0]} castShadow>
              <boxGeometry args={[2.8, 0.1, 0.6]} />
              <meshStandardMaterial color="#38bdf8" emissive="#0284c7" emissiveIntensity={0.8} />
            </mesh>
            <mesh material={spoilerMat} position={[1.0, 0.18, 0]} castShadow>
              <boxGeometry args={[0.1, 0.45, 0.4]} />
            </mesh>
            <mesh material={spoilerMat} position={[-1.0, 0.18, 0]} castShadow>
              <boxGeometry args={[0.1, 0.45, 0.4]} />
            </mesh>
          </group>
        )}

        {/* アンダーネオン管 */}
        {carUpgrades.neonColor !== 'none' && (
          <group position={[0, 0.05, 0]}>
            <pointLight color={carUpgrades.neonColor} intensity={5.0} distance={4.5} />
            <mesh rotation={[-Math.PI / 2, 0, 0]}>
              <planeGeometry args={[2.4, 4.8]} />
              <meshBasicMaterial color={carUpgrades.neonColor} transparent opacity={0.6} />
            </mesh>
          </group>
        )}

        {/* ヘッドライト */}
        <spotLight
          position={[0, 0.8, 2.5]}
          angle={Math.PI / 5}
          penumbra={0.4}
          intensity={3}
          distance={60}
          castShadow
          color="#fffbeb"
        />
        <mesh position={[0.8, 0.6, 2.41]}>
          <planeGeometry args={[0.4, 0.2]} />
          <meshBasicMaterial color="#ffffee" />
        </mesh>
        <mesh position={[-0.8, 0.6, 2.41]}>
          <planeGeometry args={[0.4, 0.2]} />
          <meshBasicMaterial color="#ffffee" />
        </mesh>

        {/* テールランプ */}
        <mesh position={[0.8, 0.6, -2.41]} rotation={[0, Math.PI, 0]}>
          <planeGeometry args={[0.4, 0.2]} />
          <meshBasicMaterial color="#ef4444" />
        </mesh>
        <mesh position={[-0.8, 0.6, -2.41]} rotation={[0, Math.PI, 0]}>
          <planeGeometry args={[0.4, 0.2]} />
          <meshBasicMaterial color="#ef4444" />
        </mesh>

        {/* マフラー (エキゾースト) */}
        <mesh position={[0.7, 0.3, -2.42]} rotation={[Math.PI / 2, 0, 0]}>
          <cylinderGeometry args={[0.1, 0.1, 0.3, 12]} />
          <meshStandardMaterial color="#71717a" metalness={0.9} />
        </mesh>
        <mesh position={[-0.7, 0.3, -2.42]} rotation={[Math.PI / 2, 0, 0]}>
          <cylinderGeometry args={[0.1, 0.1, 0.3, 12]} />
          <meshStandardMaterial color="#71717a" metalness={0.9} />
        </mesh>

        {/* タイヤ */}
        <mesh material={tireMaterial} position={[1.1, 0.4, 1.5]} rotation={[0, 0, Math.PI / 2]} castShadow>
          <cylinderGeometry args={[0.42, 0.42, 0.3, 16]} />
        </mesh>
        <mesh material={tireMaterial} position={[-1.1, 0.4, 1.5]} rotation={[0, 0, Math.PI / 2]} castShadow>
          <cylinderGeometry args={[0.42, 0.42, 0.3, 16]} />
        </mesh>
        <mesh material={tireMaterial} position={[1.1, 0.4, -1.5]} rotation={[0, 0, Math.PI / 2]} castShadow>
          <cylinderGeometry args={[0.42, 0.42, 0.3, 16]} />
        </mesh>
        <mesh material={tireMaterial} position={[-1.1, 0.4, -1.5]} rotation={[0, 0, Math.PI / 2]} castShadow>
          <cylinderGeometry args={[0.42, 0.42, 0.3, 16]} />
        </mesh>
      </group>

      {/* ドリフトスモーク */}
      <instancedMesh ref={smokeMeshRef} args={[undefined, undefined, 30]}>
        <sphereGeometry args={[0.5, 6, 6]} />
        <meshBasicMaterial color="#e4e4e7" transparent opacity={0.4} depthWrite={false} />
      </instancedMesh>

      {/* ニトロバックファイア */}
      <instancedMesh ref={nitroMeshRef} args={[undefined, undefined, 25]}>
        <sphereGeometry args={[0.4, 6, 6]} />
        <meshBasicMaterial color="#38bdf8" transparent opacity={0.8} depthWrite={false} />
      </instancedMesh>
    </>
  );
}
