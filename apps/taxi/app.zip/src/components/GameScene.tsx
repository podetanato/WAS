import { useEffect, useState, useCallback, useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Environment, Sky } from '@react-three/drei';
import { EffectComposer, Bloom } from '@react-three/postprocessing';
import * as THREE from 'three';
import { Car } from './Car';
import { NPCVehicles } from './NPCVehicles';
import { MapGenerator } from './MapGenerator';
import { generateCityMap, getRandomRoadPosition, MapData } from '../utils/mapLogic';
import { useGameStore, Passenger } from '../store/gameStore';

function FpsTracker() {
  const setFps = useGameStore(state => state.setFps);
  const frameCount = useRef(0);
  const lastTime = useRef(performance.now());

  useFrame(() => {
    frameCount.current++;
    const now = performance.now();
    const elapsed = now - lastTime.current;
    
    // 0.3秒ごとにFPSを計算してストアを更新
    if (elapsed >= 300) {
      const currentFps = Math.round((frameCount.current * 1000) / elapsed);
      setFps(currentFps);
      frameCount.current = 0;
      lastTime.current = now;
    }
  });

  return null;
}

const PASSENGER_NAMES = [
  'ビジネスマン 佐藤', '学生 タナカ', '観光客 スミス', 'おばあちゃん キヨ', '急ぎの客 ケン',
  '買い物帰り マリ', '会社員 スズキ', '旅行者 エミリー', 'シェフ ヤマダ'
];

function PassengersDisplay() {
  const passengers = useGameStore(state => state.passengers);
  const hasPassenger = useGameStore(state => state.hasPassenger);

  if (hasPassenger) return null;

  return (
    <group>
      {passengers.map((p) => (
        <group key={p.id} position={[p.pos.x, 0, p.pos.z]}>
          {/* 乗客キャラクター */}
          <mesh position={[0, 1, 0]} castShadow>
            <capsuleGeometry args={[0.35, 0.7, 4, 8]} />
            <meshStandardMaterial color="#3b82f6" roughness={0.4} />
          </mesh>
          {/* 頭部 */}
          <mesh position={[0, 1.7, 0]} castShadow>
            <sphereGeometry args={[0.25, 8, 8]} />
            <meshStandardMaterial color="#fde047" roughness={0.6} />
          </mesh>
          {/* 目立つ光の柱 */}
          <mesh position={[0, 8, 0]}>
            <cylinderGeometry args={[0.8, 0.8, 16, 12]} />
            <meshBasicMaterial color="#60a5fa" transparent opacity={0.25} blending={THREE.AdditiveBlending} depthWrite={false} />
          </mesh>
        </group>
      ))}
    </group>
  );
}

function DestinationMarker() {
  const activePassenger = useGameStore(state => state.activePassenger);
  const hasPassenger = useGameStore(state => state.hasPassenger);

  if (!hasPassenger || !activePassenger) return null;

  const dest = activePassenger.destinationPos;

  return (
    <group position={[dest.x, 0.1, dest.z]}>
      {/* 目的地のサークル */}
      <mesh rotation={[-Math.PI / 2, 0, 0]}>
        <ringGeometry args={[3.5, 4.5, 32]} />
        <meshBasicMaterial color="#10b981" transparent opacity={0.85} side={THREE.DoubleSide} />
      </mesh>
      {/* 目的地サークル内装 */}
      <mesh rotation={[-Math.PI / 2, 0, 0]}>
        <circleGeometry args={[3.2, 32]} />
        <meshBasicMaterial color="#34d399" transparent opacity={0.3} side={THREE.DoubleSide} />
      </mesh>
      {/* 光の柱 */}
      <mesh position={[0, 12, 0]}>
        <cylinderGeometry args={[3.5, 3.5, 24, 24]} />
        <meshBasicMaterial color="#34d399" transparent opacity={0.3} blending={THREE.AdditiveBlending} depthWrite={false} />
      </mesh>
    </group>
  );
}

export function GameScene() {
  const [localMapData, setLocalMapData] = useState<MapData | null>(null);
  const passengers = useGameStore(state => state.passengers);
  const setPassengers = useGameStore(state => state.setPassengers);
  const hasPassenger = useGameStore(state => state.hasPassenger);
  const setStoreMapData = useGameStore(state => state.setMapData);
  const enableShadows = useGameStore(state => state.enableShadows);
  const ultraLowMode = useGameStore(state => state.ultraLowMode);

  // マップの初期生成
  useEffect(() => {
    const data = generateCityMap();
    setLocalMapData(data);
    setStoreMapData(data);
  }, [setStoreMapData]);

  // 新しい乗客を生成するヘルパー関数
  const spawnPassenger = useCallback((map: MapData, id: string): Passenger => {
    const startPos = getRandomRoadPosition(map.roads);
    const endPos = getRandomRoadPosition(map.roads);
    const name = PASSENGER_NAMES[Math.floor(Math.random() * PASSENGER_NAMES.length)];
    return {
      id,
      pos: startPos,
      destinationPos: endPos,
      fareBonus: Math.floor(Math.random() * 20),
      name,
    };
  }, []);

  // 常に5人の乗客を維持する
  useEffect(() => {
    if (!localMapData) return;

    const TARGET_PASSENGERS = 5;
    if (passengers.length < TARGET_PASSENGERS && !hasPassenger) {
      const needed = TARGET_PASSENGERS - passengers.length;
      const newPassengers = [...passengers];
      for (let i = 0; i < needed; i++) {
        newPassengers.push(spawnPassenger(localMapData, `p-${Date.now()}-${i}-${Math.random()}`));
      }
      setPassengers(newPassengers);
    }
  }, [localMapData, passengers, hasPassenger, setPassengers, spawnPassenger]);

  if (!localMapData) return null;

  const sunPosition = new THREE.Vector3(120, 70, 100);
  const isShadowActive = enableShadows && !ultraLowMode;

  return (
    <Canvas
      shadows={isShadowActive}
      camera={{ position: [0, 20, -20], fov: 55 }}
      dpr={ultraLowMode ? 0.75 : [1, 1.5]} // ウルトラ低負荷モード時は解像度を下げて劇的に軽量化
      gl={{ 
        antialias: !ultraLowMode, 
        powerPreference: 'high-performance',
        stencil: false,
        depth: true,
      }}
    >
      <FpsTracker />
      <Sky distance={450000} sunPosition={sunPosition} inclination={0} azimuth={0.25} />
      
      {/* 効率的で軽量なライティング */}
      <ambientLight intensity={ultraLowMode ? 0.8 : 0.4} />
      <directionalLight
        castShadow={isShadowActive}
        position={sunPosition}
        intensity={ultraLowMode ? 1.8 : 2.2}
        shadow-mapSize={isShadowActive ? [1024, 1024] : [256, 256]}
        shadow-camera-left={-150}
        shadow-camera-right={150}
        shadow-camera-top={150}
        shadow-camera-bottom={-150}
        shadow-camera-near={1}
        shadow-camera-far={400}
        shadow-bias={-0.0004}
      />
      
      {/* 周辺環境 (通常モード時のみ) */}
      {!ultraLowMode && <Environment preset="city" />}

      {/* ポストプロセス (通常モード時のみ) */}
      {!ultraLowMode && (
        <EffectComposer>
          <Bloom luminanceThreshold={1.1} mipmapBlur intensity={1.2} />
        </EffectComposer>
      )}

      {/* ゲーム要素 */}
      <MapGenerator mapData={localMapData} />
      <NPCVehicles />
      <Car />
      
      <PassengersDisplay />
      <DestinationMarker />
    </Canvas>
  );
}
