import { useGameStore } from '../store/gameStore';
import { Zap } from 'lucide-react';

export function Speedometer() {
  const carSpeed = useGameStore(state => state.carSpeed);
  const carGear = useGameStore(state => state.carGear);
  const isDrifting = useGameStore(state => state.isDrifting);
  const isNitroActive = useGameStore(state => state.isNitroActive);
  const nitroLeft = useGameStore(state => state.nitroLeft);
  
  const displaySpeed = Math.round(carSpeed * 2.5); // km/h

  let gearText = carGear.toString();
  if (carGear === -1) gearText = 'R';
  if (carGear === 0) gearText = 'N';

  return (
    <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-10 pointer-events-none flex items-end gap-3">
      {/* ギア表示 */}
      <div className="w-16 h-16 rounded-2xl border-2 border-zinc-800 shadow-2xl bg-zinc-900/90 backdrop-blur flex flex-col items-center justify-center mb-1">
        <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-wider">GEAR</span>
        <span className={`text-2xl font-black font-mono ${carGear === -1 ? 'text-rose-500' : carGear === 0 ? 'text-zinc-400' : 'text-amber-400'}`}>
          {gearText}
        </span>
      </div>

      {/* スピードメーター本体 */}
      <div className="relative flex flex-col items-center">
        {/* ドリフト & ニトロ バッジ */}
        <div className="absolute -top-8 flex gap-2">
          {isNitroActive && (
            <div className="px-3 py-0.5 rounded-full bg-cyan-500 text-black font-black text-xs tracking-widest uppercase shadow-lg shadow-cyan-500/50 animate-bounce border border-cyan-300">
              NITRO BOOST !
            </div>
          )}
          {isDrifting && (
            <div className="px-3 py-0.5 rounded-full bg-rose-500 text-white font-black text-xs tracking-widest uppercase shadow-lg shadow-rose-500/50 animate-pulse border border-rose-400">
              DRIFT !
            </div>
          )}
        </div>

        <div 
          className={`w-44 h-44 rounded-full border-4 shadow-2xl relative overflow-hidden flex flex-col items-center justify-center bg-zinc-900/90 backdrop-blur transition-all duration-300 ${
            isNitroActive ? 'border-cyan-400 shadow-cyan-500/30' : 'border-zinc-800'
          }`}
        >
          <div className="z-10 text-center">
            <div 
              className={`text-4xl font-black font-mono italic tracking-tighter transition-colors ${
                isNitroActive ? 'text-cyan-300' : 'text-white'
              }`} 
              style={{ textShadow: isNitroActive ? '0 0 16px rgba(56,189,248,0.8)' : '0 0 12px rgba(255,255,255,0.4)' }}
            >
              {displaySpeed}
            </div>
            <div className="text-[10px] font-extrabold text-zinc-400 uppercase tracking-widest mt-0.5">
              km/h
            </div>
          </div>
          
          {/* スピードゲージの円弧 */}
          <svg className="absolute inset-0 w-full h-full -rotate-90" viewBox="0 0 100 100">
            <circle 
              cx="50" cy="50" r="44" 
              fill="none" 
              stroke="#27272a" 
              strokeWidth="5" 
            />
            <circle 
              cx="50" cy="50" r="44" 
              fill="none" 
              stroke={isNitroActive ? '#38bdf8' : isDrifting ? '#f43f5e' : displaySpeed > 140 ? '#ef4444' : '#fbbf24'} 
              strokeWidth="5" 
              strokeDasharray={`${Math.min((displaySpeed / 180) * 276, 276)} 276`}
              strokeLinecap="round"
              className="transition-all duration-75 ease-out"
            />
          </svg>
        </div>
      </div>

      {/* ニトロゲージ */}
      <div className="w-16 h-28 rounded-2xl border-2 border-zinc-800 shadow-2xl bg-zinc-900/90 backdrop-blur flex flex-col items-center justify-between p-2 mb-1">
        <div className="flex items-center gap-1 text-[9px] font-black text-cyan-400 uppercase tracking-wider">
          <Zap className="w-3 h-3 text-cyan-400 fill-cyan-400" />
          <span>NITRO</span>
        </div>
        
        {/* 縦型ゲージバー */}
        <div className="w-4 h-16 bg-zinc-950 rounded-full border border-zinc-800 overflow-hidden flex flex-col justify-end p-0.5">
          <div 
            className="w-full rounded-full bg-gradient-to-t from-cyan-600 via-cyan-400 to-sky-200 transition-all duration-75"
            style={{ 
              height: `${nitroLeft}%`,
              boxShadow: isNitroActive ? '0 0 10px #38bdf8' : 'none'
            }}
          />
        </div>

        <span className="text-[9px] font-mono font-bold text-zinc-400">
          [N]
        </span>
      </div>
    </div>
  );
}
