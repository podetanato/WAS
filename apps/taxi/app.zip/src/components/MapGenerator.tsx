import { useMemo, useEffect, useRef } from 'react';
import * as THREE from 'three';
import { MapData, CELL_SIZE, GRID_WIDTH, GRID_HEIGHT, CellType } from '../utils/mapLogic';

interface MapGeneratorProps {
  mapData: MapData;
}

// リアルな道路テクスチャをCanvasで動的生成
function createRoadTextures() {
  const size = 512;
  
  // 1. 直線道路テクスチャ（Z軸方向）
  const canvasStraight = document.createElement('canvas');
  canvasStraight.width = size;
  canvasStraight.height = size;
  const ctxS = canvasStraight.getContext('2d')!;

  // アスファルト下地
  ctxS.fillStyle = '#22252a';
  ctxS.fillRect(0, 0, size, size);

  // アスファルトのノイズ感
  for (let i = 0; i < 4000; i++) {
    const nx = Math.random() * size;
    const ny = Math.random() * size;
    const brightness = Math.floor(25 + Math.random() * 20);
    ctxS.fillStyle = `rgb(${brightness},${brightness},${brightness})`;
    ctxS.fillRect(nx, ny, 2, 2);
  }

  // 左右の白線
  ctxS.fillStyle = '#e4e4e7';
  ctxS.fillRect(20, 0, 12, size);
  ctxS.fillRect(size - 32, 0, 12, size);

  // 中央の黄色い破線
  ctxS.fillStyle = '#f59e0b';
  const dashLength = 36;
  const gapLength = 28;
  for (let y = 10; y < size; y += dashLength + gapLength) {
    ctxS.fillRect(size / 2 - 4, y, 8, dashLength);
  }

  // 2. 交差点（Intersection）テクスチャ
  const canvasInter = document.createElement('canvas');
  canvasInter.width = size;
  canvasInter.height = size;
  const ctxI = canvasInter.getContext('2d')!;

  ctxI.fillStyle = '#22252a';
  ctxI.fillRect(0, 0, size, size);

  for (let i = 0; i < 4000; i++) {
    const nx = Math.random() * size;
    const ny = Math.random() * size;
    const brightness = Math.floor(25 + Math.random() * 20);
    ctxI.fillStyle = `rgb(${brightness},${brightness},${brightness})`;
    ctxI.fillRect(nx, ny, 2, 2);
  }

  // 横断歩道（4方向のゼブラゾーン）
  ctxI.fillStyle = '#ffffff';
  const zebraWidth = 14;
  const zebraGap = 12;

  // 上下の横断歩道
  for (let x = 40; x < size - 40; x += zebraWidth + zebraGap) {
    ctxI.fillRect(x, 24, zebraWidth, 36);
    ctxI.fillRect(x, size - 60, zebraWidth, 36);
  }
  // 左右の横断歩道
  for (let y = 40; y < size - 40; y += zebraWidth + zebraGap) {
    ctxI.fillRect(24, y, 36, zebraWidth);
    ctxI.fillRect(size - 60, y, 36, zebraWidth);
  }

  // 中央にマンホール
  ctxI.fillStyle = '#18181b';
  ctxI.beginPath();
  ctxI.arc(size / 2, size / 2, 16, 0, Math.PI * 2);
  ctxI.fill();
  ctxI.strokeStyle = '#52525b';
  ctxI.lineWidth = 4;
  ctxI.stroke();

  const straightTex = new THREE.CanvasTexture(canvasStraight);
  straightTex.wrapS = THREE.RepeatWrapping;
  straightTex.wrapT = THREE.RepeatWrapping;

  const interTex = new THREE.CanvasTexture(canvasInter);

  return { straightTex, interTex };
}

export function MapGenerator({ mapData }: MapGeneratorProps) {
  const { straightTex, interTex } = useMemo(() => createRoadTextures(), []);

  // InstancedMeshのRef
  const buildingMeshRefs = useRef<(THREE.InstancedMesh | null)[]>([]);
  const sidewalkMeshRef = useRef<THREE.InstancedMesh>(null);
  const roadStraightRef = useRef<THREE.InstancedMesh>(null);
  const roadInterRef = useRef<THREE.InstancedMesh>(null);
  const parkRef = useRef<THREE.InstancedMesh>(null);
  const trunkRef = useRef<THREE.InstancedMesh>(null);
  const leavesRef = useRef<THREE.InstancedMesh>(null);

  // カラーパレットごとにビルを分類してInstancedMeshを最小限に（Draw Callを10回未満に削減）
  const colorBuckets = useMemo(() => {
    const buckets: Record<string, { x: number; z: number; height: number; scaleX: number; scaleZ: number }[]> = {};
    mapData.buildings.forEach((b) => {
      if (!buckets[b.color]) buckets[b.color] = [];
      buckets[b.color].push(b);
    });
    return buckets;
  }, [mapData.buildings]);

  // 道路を「直線（縦・横）」と「交差点」に分類
  const { straightRoads, interRoads } = useMemo(() => {
    const straight: { x: number; z: number; rot: number }[] = [];
    const inter: { x: number; z: number }[] = [];

    const halfW = Math.floor(GRID_WIDTH / 2);
    const halfH = Math.floor(GRID_HEIGHT / 2);

    for (let z = 0; z < GRID_HEIGHT; z++) {
      for (let x = 0; x < GRID_WIDTH; x++) {
        if (mapData.grid[z][x] === CellType.ROAD) {
          const posX = (x - halfW) * CELL_SIZE;
          const posZ = (z - halfH) * CELL_SIZE;
          const isVert = x % 4 === 0;
          const isHoriz = z % 4 === 0;

          if (isVert && isHoriz) {
            inter.push({ x: posX, z: posZ });
          } else if (isVert) {
            // 縦の道路 (回転0)
            straight.push({ x: posX, z: posZ, rot: 0 });
          } else {
            // 横の道路 (回転90度)
            straight.push({ x: posX, z: posZ, rot: Math.PI / 2 });
          }
        }
      }
    }
    return { straightRoads: straight, interRoads: inter };
  }, [mapData]);

  // InstancedMeshのトランスフォーム設定（初回およびマップ変更時のみ一括実行）
  useEffect(() => {
    const dummy = new THREE.Object3D();

    // 1. 直線道路
    if (roadStraightRef.current) {
      straightRoads.forEach((r, i) => {
        dummy.position.set(r.x, 0.02, r.z);
        dummy.rotation.set(-Math.PI / 2, 0, r.rot);
        dummy.scale.set(1, 1, 1);
        dummy.updateMatrix();
        roadStraightRef.current!.setMatrixAt(i, dummy.matrix);
      });
      roadStraightRef.current.instanceMatrix.needsUpdate = true;
    }

    // 2. 交差点
    if (roadInterRef.current) {
      interRoads.forEach((r, i) => {
        dummy.position.set(r.x, 0.02, r.z);
        dummy.rotation.set(-Math.PI / 2, 0, 0);
        dummy.scale.set(1, 1, 1);
        dummy.updateMatrix();
        roadInterRef.current!.setMatrixAt(i, dummy.matrix);
      });
      roadInterRef.current.instanceMatrix.needsUpdate = true;
    }

    // 3. 歩道/土台
    if (sidewalkMeshRef.current) {
      mapData.buildings.forEach((b, i) => {
        dummy.position.set(b.x, 0.25, b.z);
        dummy.rotation.set(0, 0, 0);
        dummy.scale.set(1, 1, 1);
        dummy.updateMatrix();
        sidewalkMeshRef.current!.setMatrixAt(i, dummy.matrix);
      });
      sidewalkMeshRef.current.instanceMatrix.needsUpdate = true;
    }

    // 4. ビル群 (カラーバケットごと)
    Object.keys(colorBuckets).forEach((color, bucketIdx) => {
      const mesh = buildingMeshRefs.current[bucketIdx];
      if (mesh) {
        const buildings = colorBuckets[color];
        buildings.forEach((b, i) => {
          dummy.position.set(b.x, b.height / 2 + 0.5, b.z);
          dummy.rotation.set(0, 0, 0);
          dummy.scale.set(b.scaleX / CELL_SIZE, b.height, b.scaleZ / CELL_SIZE);
          dummy.updateMatrix();
          mesh.setMatrixAt(i, dummy.matrix);
        });
        mesh.instanceMatrix.needsUpdate = true;
      }
    });

    // 5. 公園
    if (parkRef.current) {
      mapData.parks.forEach((p, i) => {
        dummy.position.set(p.x, 0.03, p.z);
        dummy.rotation.set(-Math.PI / 2, 0, 0);
        dummy.scale.set(1, 1, 1);
        dummy.updateMatrix();
        parkRef.current!.setMatrixAt(i, dummy.matrix);
      });
      parkRef.current.instanceMatrix.needsUpdate = true;
    }

    // 6. 木 (幹と葉)
    if (trunkRef.current && leavesRef.current) {
      let treeIdx = 0;
      mapData.parks.forEach((p) => {
        // 木1
        dummy.position.set(p.x + 3, 2.5, p.z + 3);
        dummy.rotation.set(0, 0, 0);
        dummy.scale.set(1, 1, 1);
        dummy.updateMatrix();
        trunkRef.current!.setMatrixAt(treeIdx, dummy.matrix);

        dummy.position.set(p.x + 3, 5.5, p.z + 3);
        dummy.updateMatrix();
        leavesRef.current!.setMatrixAt(treeIdx, dummy.matrix);
        treeIdx++;

        // 木2
        dummy.position.set(p.x - 3, 2.0, p.z - 2);
        dummy.updateMatrix();
        trunkRef.current!.setMatrixAt(treeIdx, dummy.matrix);

        dummy.position.set(p.x - 3, 4.5, p.z - 2);
        dummy.updateMatrix();
        leavesRef.current!.setMatrixAt(treeIdx, dummy.matrix);
        treeIdx++;
      });
      trunkRef.current.instanceMatrix.needsUpdate = true;
      leavesRef.current.instanceMatrix.needsUpdate = true;
    }
  }, [mapData, colorBuckets, straightRoads, interRoads]);

  // マテリアルの定義
  const roadMatStraight = useMemo(() => new THREE.MeshStandardMaterial({
    map: straightTex,
    roughness: 0.85,
    metalness: 0.1,
  }), [straightTex]);

  const roadMatInter = useMemo(() => new THREE.MeshStandardMaterial({
    map: interTex,
    roughness: 0.85,
    metalness: 0.1,
  }), [interTex]);

  const sidewalkMat = useMemo(() => new THREE.MeshStandardMaterial({
    color: '#6b7280',
    roughness: 0.9,
  }), []);

  const parkMat = useMemo(() => new THREE.MeshStandardMaterial({
    color: '#15803d',
    roughness: 0.95,
  }), []);

  const trunkMat = useMemo(() => new THREE.MeshStandardMaterial({
    color: '#451a03',
    roughness: 0.9,
  }), []);

  const leavesMat = useMemo(() => new THREE.MeshStandardMaterial({
    color: '#16a34a',
    roughness: 0.8,
  }), []);

  const totalWidth = GRID_WIDTH * CELL_SIZE;
  const totalHeight = GRID_HEIGHT * CELL_SIZE;

  return (
    <group>
      {/* 巨大な地面 (ベース) */}
      <mesh position={[0, -0.1, 0]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <planeGeometry args={[totalWidth + 100, totalHeight + 100]} />
        <meshStandardMaterial color="#1f242d" roughness={1.0} />
      </mesh>

      {/* 1. 直線道路のInstancedMesh */}
      {straightRoads.length > 0 && (
        <instancedMesh
          ref={roadStraightRef}
          args={[undefined, undefined, straightRoads.length]}
          receiveShadow
          material={roadMatStraight}
        >
          <planeGeometry args={[CELL_SIZE, CELL_SIZE]} />
        </instancedMesh>
      )}

      {/* 2. 交差点のInstancedMesh */}
      {interRoads.length > 0 && (
        <instancedMesh
          ref={roadInterRef}
          args={[undefined, undefined, interRoads.length]}
          receiveShadow
          material={roadMatInter}
        >
          <planeGeometry args={[CELL_SIZE, CELL_SIZE]} />
        </instancedMesh>
      )}

      {/* 3. 歩道/土台のInstancedMesh */}
      {mapData.buildings.length > 0 && (
        <instancedMesh
          ref={sidewalkMeshRef}
          args={[undefined, undefined, mapData.buildings.length]}
          receiveShadow
          material={sidewalkMat}
        >
          <boxGeometry args={[CELL_SIZE - 2, 0.5, CELL_SIZE - 2]} />
        </instancedMesh>
      )}

      {/* 4. ビル群 (カラーごとにInstancedMesh化してDrawCallを最小化) */}
      {Object.keys(colorBuckets).map((color, idx) => {
        const count = colorBuckets[color].length;
        const isGlass = idx % 2 === 0;
        return (
          <instancedMesh
            key={`bldg-color-${color}`}
            ref={(el) => { buildingMeshRefs.current[idx] = el; }}
            args={[undefined, undefined, count]}
            castShadow
            receiveShadow
          >
            <boxGeometry args={[CELL_SIZE, 1, CELL_SIZE]} />
            <meshPhysicalMaterial
              color={color}
              metalness={isGlass ? 0.8 : 0.2}
              roughness={isGlass ? 0.15 : 0.75}
              clearcoat={isGlass ? 1.0 : 0.0}
            />
          </instancedMesh>
        );
      })}

      {/* 5. 公園のInstancedMesh */}
      {mapData.parks.length > 0 && (
        <instancedMesh
          ref={parkRef}
          args={[undefined, undefined, mapData.parks.length]}
          receiveShadow
          material={parkMat}
        >
          <planeGeometry args={[CELL_SIZE - 1, CELL_SIZE - 1]} />
        </instancedMesh>
      )}

      {/* 6. 木の幹と葉 */}
      {mapData.parks.length > 0 && (
        <>
          <instancedMesh
            ref={trunkRef}
            args={[undefined, undefined, mapData.parks.length * 2]}
            castShadow
            receiveShadow
            material={trunkMat}
          >
            <cylinderGeometry args={[0.3, 0.5, 5, 8]} />
          </instancedMesh>
          <instancedMesh
            ref={leavesRef}
            args={[undefined, undefined, mapData.parks.length * 2]}
            castShadow
            receiveShadow
            material={leavesMat}
          >
            <sphereGeometry args={[2.2, 8, 8]} />
          </instancedMesh>
        </>
      )}
    </group>
  );
}
