import React, { useEffect, useState } from 'react';
import { useGameStore } from '../store/gameStore';
import { soundEngine } from '../utils/audio';
import { exitToWAS, WAS_APP_ID } from '../utils/wasBridge';
import { Save, LogOut, RotateCcw, Check, Database } from 'lucide-react';

export function SettingsMenu() {
  const cameraMode = useGameStore(state => state.cameraMode);
  const toggleCameraMode = useGameStore(state => state.toggleCameraMode);
  const isSettingsOpen = useGameStore(state => state.isSettingsOpen);
  const showControls = useGameStore(state => state.showControls);
  const enableShadows = useGameStore(state => state.enableShadows);
  const ultraLowMode = useGameStore(state => state.ultraLowMode);
  const soundVolume = useGameStore(state => state.soundVolume);
  const lastSavedAt = useGameStore(state => state.lastSavedAt);
  const passengersDelivered = useGameStore(state => state.passengersDelivered);
  const totalFaresEarned = useGameStore(state => state.totalFaresEarned);
  
  const toggleSettings = useGameStore(state => state.toggleSettings);
  const updateSettings = useGameStore(state => state.updateSettings);
  const saveGame = useGameStore(state => state.saveGame);
  const resetGame = useGameStore(state => state.resetGame);

  const [savedNotification, setSavedNotification] = useState(false);
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Escape') {
        toggleSettings();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [toggleSettings]);

  useEffect(() => {
    soundEngine.setVolume(soundVolume);
  }, [soundVolume]);

  if (!isSettingsOpen) return null;

  const handleManualSave = () => {
    saveGame();
    setSavedNotification(true);
    setTimeout(() => setSavedNotification(false), 2000);
  };

  const handleResetConfirm = () => {
    resetGame();
    setShowResetConfirm(false);
  };

  return (
    <div className="absolute inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-150">
      <div className="bg-zinc-950 border border-zinc-800 rounded-3xl shadow-2xl p-6 sm:p-8 w-full max-w-lg max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between border-b border-zinc-800 pb-4 mb-6">
          <div>
            <div className="text-[10px] font-bold text-amber-500 uppercase tracking-widest">Graphics & Game System</div>
            <h2 className="text-2xl font-black text-white italic tracking-wider">設定 (SETTINGS)</h2>
          </div>
          <div className="flex items-center gap-1.5 px-3 py-1 bg-zinc-900 border border-zinc-700/60 rounded-full">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-[11px] font-mono font-bold text-zinc-300">WAS: {WAS_APP_ID}</span>
          </div>
        </div>
        
        <div className="space-y-5">
          {/* WAS (Web App Store) 連携情報 & セーブ */}
          <div className="bg-zinc-900/90 border border-zinc-800 rounded-2xl p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Database className="w-4 h-4 text-amber-400" />
                <span className="text-white font-bold text-sm">WAS データストレージ</span>
              </div>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                自動保存 有効
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs text-zinc-400 mb-3 bg-zinc-950/60 p-2.5 rounded-xl border border-zinc-800/80">
              <div>
                <span className="text-zinc-500 block text-[10px]">送迎完了人数</span>
                <span className="text-amber-400 font-bold font-mono text-sm">{passengersDelivered} 人</span>
              </div>
              <div>
                <span className="text-zinc-500 block text-[10px]">累計獲得運賃</span>
                <span className="text-emerald-400 font-bold font-mono text-sm">${totalFaresEarned}</span>
              </div>
              <div className="col-span-2 text-[10px] text-zinc-500 mt-1 border-t border-zinc-800/60 pt-1 flex justify-between">
                <span>最終保存:</span>
                <span className="font-mono text-zinc-400">
                  {lastSavedAt ? new Date(lastSavedAt).toLocaleTimeString() : '未保存'}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleManualSave}
                className="flex-1 bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-bold py-2 px-3 rounded-xl border border-zinc-700 flex items-center justify-center gap-1.5 transition-all active:scale-98 cursor-pointer"
              >
                {savedNotification ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-300">保存完了!</span>
                  </>
                ) : (
                  <>
                    <Save className="w-3.5 h-3.5 text-amber-400" />
                    <span>即時セーブ</span>
                  </>
                )}
              </button>

              <button
                onClick={() => setShowResetConfirm(true)}
                className="bg-rose-950/40 hover:bg-rose-900/50 text-rose-300 border border-rose-800/50 text-xs font-bold py-2 px-3 rounded-xl flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                title="セーブデータをリセット"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>データ初期化</span>
              </button>
            </div>

            {showResetConfirm && (
              <div className="mt-3 p-3 bg-rose-950/80 border border-rose-600 rounded-xl text-xs space-y-2">
                <p className="text-rose-200 font-bold">
                  所持金や改造レベル、購入した車をすべて初期化しますか？
                </p>
                <div className="flex gap-2">
                  <button
                    onClick={handleResetConfirm}
                    className="bg-rose-600 hover:bg-rose-500 text-white font-bold px-3 py-1 rounded-lg text-xs"
                  >
                    はい、初期化する
                  </button>
                  <button
                    onClick={() => setShowResetConfirm(false)}
                    className="bg-zinc-800 hover:bg-zinc-700 text-zinc-300 px-3 py-1 rounded-lg text-xs"
                  >
                    キャンセル
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* ウルトラ低負荷モード */}
          <div className="bg-gradient-to-r from-cyan-950/40 to-blue-950/20 border border-cyan-500/30 rounded-2xl p-4 flex items-center justify-between">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-white font-bold text-sm">ウルトラ低負荷モード</span>
                <span className="text-[9px] font-bold px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-400/40">
                  超軽量
                </span>
              </div>
              <div className="text-xs text-zinc-400 mt-1 leading-relaxed">
                解像度とエフェクトを最小化し、FPSを最大化します
              </div>
            </div>
            <button 
              className={`w-13 h-7 rounded-full transition-all relative shrink-0 ${ultraLowMode ? 'bg-cyan-500 shadow-[0_0_12px_rgba(6,182,212,0.6)]' : 'bg-zinc-800'}`}
              onClick={() => {
                const nextMode = !ultraLowMode;
                updateSettings({ 
                  ultraLowMode: nextMode,
                  enableShadows: nextMode ? false : enableShadows 
                });
              }}
            >
              <div className={`w-5 h-5 rounded-full bg-white absolute top-1 transition-transform shadow-md ${ultraLowMode ? 'left-7' : 'left-1'}`} />
            </button>
          </div>

          {/* カメラ視点切り替え */}
          <div className="bg-zinc-900/80 border border-zinc-800 rounded-2xl p-3.5 flex items-center justify-between">
            <div>
              <div className="text-white font-bold text-sm flex items-center gap-2">
                <span>カメラ視点</span>
                <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded ${cameraMode === 'FPS' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' : 'bg-blue-500/20 text-blue-300 border border-blue-500/30'}`}>
                  {cameraMode === 'FPS' ? 'FPS (運転席視点)' : 'TPS (三人称視点)'}
                </span>
              </div>
              <div className="text-xs text-zinc-400 mt-0.5">
                [C] キーでゲーム中いつでも素早く切り替え可能
              </div>
            </div>
            <button
              onClick={toggleCameraMode}
              className="bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-bold px-3 py-1.5 rounded-xl border border-zinc-700 transition-all hover:scale-105 active:scale-95 cursor-pointer"
            >
              切替 [C]
            </button>
          </div>

          <div className="flex items-center justify-between py-1">
            <div>
              <label className="text-zinc-200 font-medium text-sm">操作ガイドの表示</label>
              <div className="text-[11px] text-zinc-500">画面左下のキーボード操作UI</div>
            </div>
            <button 
              className={`w-12 h-6 rounded-full transition-colors relative ${showControls ? 'bg-amber-500' : 'bg-zinc-800'}`}
              onClick={() => updateSettings({ showControls: !showControls })}
            >
              <div className={`w-4 h-4 rounded-full bg-white absolute top-1 transition-transform ${showControls ? 'left-7' : 'left-1'}`} />
            </button>
          </div>

          <div className="flex items-center justify-between py-1">
            <div>
              <label className="text-zinc-200 font-medium text-sm">リアルタイムシャドウ (影)</label>
              <div className="text-[11px] text-zinc-500">{ultraLowMode ? '低負荷モード中は無効' : '高品質な建物の影'}</div>
            </div>
            <button 
              disabled={ultraLowMode}
              className={`w-12 h-6 rounded-full transition-colors relative ${enableShadows && !ultraLowMode ? 'bg-amber-500' : 'bg-zinc-800 opacity-60'}`}
              onClick={() => updateSettings({ enableShadows: !enableShadows })}
            >
              <div className={`w-4 h-4 rounded-full bg-white absolute top-1 transition-transform ${enableShadows && !ultraLowMode ? 'left-7' : 'left-1'}`} />
            </button>
          </div>

          <div className="pt-2 border-t border-zinc-800/80">
            <div className="flex justify-between text-zinc-300 font-medium text-sm mb-2">
              <label>サウンド音量</label>
              <span className="font-mono text-amber-400">{Math.round(soundVolume * 100)}%</span>
            </div>
            <input 
              type="range" 
              min="0" max="1" step="0.05"
              value={soundVolume}
              onChange={(e) => updateSettings({ soundVolume: parseFloat(e.target.value) })}
              className="w-full accent-amber-500 cursor-pointer h-2 bg-zinc-800 rounded-lg"
            />
          </div>
        </div>

        <div className="mt-8 flex gap-3">
          <button 
            onClick={toggleSettings}
            className="flex-1 bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold py-3.5 rounded-2xl transition-all uppercase tracking-wider text-sm shadow-lg shadow-amber-500/20 active:scale-[0.99] cursor-pointer"
          >
            ゲームに戻る (ESC)
          </button>
          <button
            onClick={exitToWAS}
            className="bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-white px-4 py-3.5 rounded-2xl border border-zinc-800 flex items-center gap-2 text-xs font-bold transition-all cursor-pointer"
            title="WASストアに戻る"
          >
            <LogOut className="w-4 h-4" />
            <span className="hidden sm:inline">WASへ戻る</span>
          </button>
        </div>
      </div>
    </div>
  );
}
