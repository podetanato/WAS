import React from 'react';
import { useGameStore } from '../store/gameStore';
import { Gauge, Zap, Wrench, Shield, Sparkles, Palette, ChevronRight, X } from 'lucide-react';
import { soundEngine } from '../utils/audio';

const UPGRADE_DATA = [
  {
    id: 'topSpeed' as const,
    name: 'Top Speed (最高速度)',
    desc: '最高速度の上限を引き上げ、高速ギアでの伸びを強化',
    icon: Gauge,
    color: 'from-amber-500 to-orange-600',
    maxLevel: 5,
    prices: [0, 80, 180, 350, 600],
    stats: ['+0 km/h', '+15 km/h', '+30 km/h', '+50 km/h', '+75 km/h'],
  },
  {
    id: 'acceleration' as const,
    name: 'Acceleration (加速力)',
    desc: 'エンジントルクと立ち上がり加速を大幅に向上',
    icon: Zap,
    color: 'from-yellow-400 to-amber-500',
    maxLevel: 5,
    prices: [0, 70, 160, 320, 550],
    stats: ['1.0x', '1.25x', '1.55x', '1.9x', '2.4x'],
  },
  {
    id: 'handling' as const,
    name: 'Handling & Drift (旋回・グリップ)',
    desc: 'ステアリング応答性とドリフト時のコントロール性能UP',
    icon: Wrench,
    color: 'from-emerald-400 to-teal-600',
    maxLevel: 5,
    prices: [0, 60, 140, 280, 500],
    stats: ['ノーマル', 'スポーツ', 'レーシング', 'プロ', 'マスター'],
  },
  {
    id: 'nitro' as const,
    name: 'Nitro Boost (ニトロシステム)',
    desc: 'Nキー / Shiftで発動するアスファルト風ニトロブースト',
    icon: Sparkles,
    color: 'from-cyan-400 to-blue-600',
    maxLevel: 5,
    prices: [0, 90, 200, 400, 700],
    stats: ['Lv 1', 'Lv 2 (加速UP)', 'Lv 3 (長持ち)', 'Lv 4 (超加速)', 'Lv 5 (極限ブースト)'],
  },
  {
    id: 'spoiler' as const,
    name: 'Aero Spoiler (エアロスポイラー)',
    desc: '車体後部に装着するレーシングGTウィング',
    icon: Shield,
    color: 'from-purple-500 to-indigo-600',
    maxLevel: 3,
    prices: [0, 100, 250, 500],
    stats: ['なし', 'スポーツリップ', 'カーボンGTウィング', 'サイバー巨大ウィング'],
  },
];

const BODY_COLORS = [
  { name: 'タクシーイエロー', color: '#fbbf24' },
  { name: 'アスファルトブラック', color: '#09090b' },
  { name: 'クリムゾンレッド', color: '#ef4444' },
  { name: 'サイバーブルー', color: '#0284c7' },
  { name: 'ネオングリーン', color: '#10b981' },
  { name: 'パープルヘイズ', color: '#9333ea' },
  { name: 'ピュアホワイト', color: '#f8fafc' },
  { name: 'サンセットオレンジ', color: '#ea580c' },
];

const NEON_COLORS = [
  { name: 'なし', color: 'none' },
  { name: 'アイスブルー', color: '#38bdf8' },
  { name: 'サイバーパープル', color: '#a855f7' },
  { name: 'アシッドグリーン', color: '#22c55e' },
  { name: 'レッドグロー', color: '#ef4444' },
  { name: 'ゴールドアンバー', color: '#f59e0b' },
];

export function GarageMenu() {
  const isGarageOpen = useGameStore(state => state.isGarageOpen);
  const toggleGarage = useGameStore(state => state.toggleGarage);
  const score = useGameStore(state => state.score);
  const carUpgrades = useGameStore(state => state.carUpgrades);
  const buyUpgrade = useGameStore(state => state.buyUpgrade);
  const setBodyColor = useGameStore(state => state.setBodyColor);
  const setNeonColor = useGameStore(state => state.setNeonColor);

  const [activeTab, setActiveTab] = React.useState<'performance' | 'custom' | 'showroom' | 'audio'>('performance');

  const bgmGenre = useGameStore(state => state.bgmGenre);
  const updateSettings = useGameStore(state => state.updateSettings);
  const ownedCars = useGameStore(state => state.ownedCars);
  const carModel = useGameStore(state => state.carModel);
  const buyCar = useGameStore(state => state.buyCar);
  const setCarModel = useGameStore(state => state.setCarModel);

  if (!isGarageOpen) return null;

  const handleBgmChange = (genre: 'none' | 'Lo-fi' | 'Jazz' | 'Synthwave') => {
    updateSettings({ bgmGenre: genre });
    soundEngine.updateBGM(genre);
  };

  const CAR_DATA: { id: 'classic' | 'sport' | 'hyper', name: string, price: number, desc: string }[] = [
    { id: 'classic', name: 'Classic Taxi', price: 0, desc: '初期配布のブロック型タクシー' },
    { id: 'sport', name: 'Modern Sport', price: 1500, desc: '流線型の現代的なスポーツカー' },
    { id: 'hyper', name: 'Hyper Coupe', price: 5000, desc: '最高級スーパーカー仕様' },
  ];

  return (
    <div className="absolute inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 sm:p-8 animate-in fade-in duration-200">
      <div className="bg-zinc-950 border border-zinc-800 rounded-3xl shadow-2xl w-full max-w-4xl max-h-[92vh] flex flex-col overflow-hidden text-white relative">
        
        {/* Header */}
        <div className="p-6 border-b border-zinc-800 flex justify-between items-center bg-gradient-to-r from-zinc-900 via-zinc-950 to-zinc-900">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-2xl text-amber-400">
              <Wrench className="w-6 h-6" />
            </div>
            <div>
              <div className="text-xs font-bold text-amber-500 uppercase tracking-widest">Asphalt Tuning Garage</div>
              <h2 className="text-2xl font-black italic tracking-wider">タクシーカスタム工房</h2>
            </div>
          </div>

          <div className="flex items-center gap-6">
            <div className="bg-zinc-900 border border-zinc-700/60 px-5 py-2 rounded-2xl flex items-center gap-2">
              <span className="text-xs text-zinc-400 font-bold uppercase">所持金</span>
              <span className="text-xl font-black text-emerald-400 font-mono">${Math.floor(score)}</span>
            </div>

            <button 
              onClick={toggleGarage}
              className="p-2.5 rounded-full bg-zinc-800 hover:bg-zinc-700 text-zinc-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-zinc-800 bg-zinc-900/50 px-6 gap-2 overflow-x-auto whitespace-nowrap">
          <button
            onClick={() => setActiveTab('performance')}
            className={`py-3.5 px-3 font-bold text-sm border-b-2 flex items-center gap-2 transition-all ${
              activeTab === 'performance'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Gauge className="w-4 h-4" />
            性能UP
          </button>
          <button
            onClick={() => setActiveTab('custom')}
            className={`py-3.5 px-3 font-bold text-sm border-b-2 flex items-center gap-2 transition-all ${
              activeTab === 'custom'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Palette className="w-4 h-4" />
            カラー
          </button>
          <button
            onClick={() => setActiveTab('showroom')}
            className={`py-3.5 px-3 font-bold text-sm border-b-2 flex items-center gap-2 transition-all ${
              activeTab === 'showroom'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            新車購入
          </button>
          <button
            onClick={() => setActiveTab('audio')}
            className={`py-3.5 px-3 font-bold text-sm border-b-2 flex items-center gap-2 transition-all ${
              activeTab === 'audio'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Zap className="w-4 h-4" />
            オーディオ
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-4 flex-1">
          {activeTab === 'performance' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {UPGRADE_DATA.map((upg) => {
                const currentLvl = carUpgrades[upg.id];
                const isMax = currentLvl >= upg.maxLevel;
                const nextCost = isMax ? 0 : upg.prices[currentLvl];
                const canAfford = score >= nextCost && !isMax;
                const IconComponent = upg.icon;

                return (
                  <div
                    key={upg.id}
                    className="bg-zinc-900/80 border border-zinc-800/80 hover:border-zinc-700 rounded-2xl p-5 flex flex-col justify-between transition-all"
                  >
                    <div>
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center gap-3">
                          <div className={`p-2.5 rounded-xl bg-gradient-to-br ${upg.color} text-zinc-950 font-bold shadow-md`}>
                            <IconComponent className="w-5 h-5" />
                          </div>
                          <div>
                            <h3 className="font-bold text-zinc-100 text-base">{upg.name}</h3>
                            <div className="text-xs text-zinc-400">{upg.desc}</div>
                          </div>
                        </div>
                        <span className="text-xs font-mono font-bold px-2.5 py-1 bg-zinc-800 text-zinc-300 rounded-full border border-zinc-700">
                          Lv.{currentLvl}/{upg.maxLevel}
                        </span>
                      </div>

                      {/* Level Step Dots */}
                      <div className="flex gap-1.5 mb-4">
                        {Array.from({ length: upg.maxLevel }).map((_, i) => (
                          <div
                            key={i}
                            className={`h-2 flex-1 rounded-full transition-all ${
                              i < currentLvl
                                ? 'bg-amber-400 shadow-[0_0_8px_rgba(251,191,36,0.5)]'
                                : 'bg-zinc-800'
                            }`}
                          />
                        ))}
                      </div>

                      <div className="text-xs text-zinc-400 mb-4 bg-zinc-950/60 p-2.5 rounded-xl flex justify-between">
                        <span>現在の効果:</span>
                        <strong className="text-zinc-200">{upg.stats[currentLvl - 1] || 'なし'}</strong>
                      </div>
                    </div>

                    <button
                      disabled={!canAfford || isMax}
                      onClick={() => {
                        const success = buyUpgrade(upg.id);
                        if (success) soundEngine.playPiron();
                      }}
                      className={`w-full py-3 px-4 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all ${
                        isMax
                          ? 'bg-zinc-800/80 text-zinc-500 cursor-not-allowed'
                          : canAfford
                          ? 'bg-amber-500 hover:bg-amber-400 text-zinc-950 shadow-lg shadow-amber-500/20 active:scale-[0.98]'
                          : 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
                      }`}
                    >
                      {isMax ? (
                        'MAX レベル到達'
                      ) : (
                        <>
                          <span>アップグレード (${nextCost})</span>
                          <ChevronRight className="w-4 h-4" />
                        </>
                      )}
                    </button>
                  </div>
                );
              })}
            </div>
          )}

          {activeTab === 'custom' && (
            <div className="space-y-6">
              {/* 車体ペイントカラー */}
              <div className="bg-zinc-900/80 border border-zinc-800 rounded-2xl p-6">
                <h3 className="text-base font-bold text-zinc-200 mb-2 flex items-center gap-2">
                  <Palette className="w-5 h-5 text-amber-400" />
                  ボディペイント（無料変更）
                </h3>
                <p className="text-xs text-zinc-400 mb-4">
                  アスファルト風のラグジュアリーなメタリック・クリアコート塗装を選択できます。
                </p>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {BODY_COLORS.map((c) => (
                    <button
                      key={c.color}
                      onClick={() => setBodyColor(c.color)}
                      className={`p-3 rounded-xl border flex items-center gap-3 transition-all ${
                        carUpgrades.bodyColor === c.color
                          ? 'border-amber-400 bg-amber-500/10'
                          : 'border-zinc-800 hover:border-zinc-700 bg-zinc-950/40'
                      }`}
                    >
                      <div
                        className="w-7 h-7 rounded-full border border-white/20 shadow-inner"
                        style={{ backgroundColor: c.color }}
                      />
                      <span className="text-xs font-semibold text-zinc-200">{c.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* アンダーネオン管 */}
              <div className="bg-zinc-900/80 border border-zinc-800 rounded-2xl p-6">
                <h3 className="text-base font-bold text-zinc-200 mb-2 flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-cyan-400" />
                  アンダーグロー・ネオン管（無料変更）
                </h3>
                <p className="text-xs text-zinc-400 mb-4">
                  車体底部から地面を照らすアスファルト風ネオンライト
                </p>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {NEON_COLORS.map((n) => (
                    <button
                      key={n.color}
                      onClick={() => setNeonColor(n.color)}
                      className={`p-3 rounded-xl border flex items-center gap-3 transition-all ${
                        carUpgrades.neonColor === n.color
                          ? 'border-cyan-400 bg-cyan-500/10'
                          : 'border-zinc-800 hover:border-zinc-700 bg-zinc-950/40'
                      }`}
                    >
                      <div
                        className="w-7 h-7 rounded-full border border-white/20 shadow-md"
                        style={{
                          backgroundColor: n.color === 'none' ? '#27272a' : n.color,
                          boxShadow: n.color === 'none' ? 'none' : `0 0 10px ${n.color}`,
                        }}
                      />
                      <span className="text-xs font-semibold text-zinc-200">{n.name}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
          
          {activeTab === 'showroom' && (
            <div className="space-y-4">
              {CAR_DATA.map(car => {
                const isOwned = ownedCars.includes(car.id);
                const isSelected = carModel === car.id;
                const canAfford = score >= car.price;

                return (
                  <div key={car.id} className="bg-zinc-900/80 border border-zinc-800 rounded-2xl p-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                    <div>
                      <h3 className="text-xl font-black italic text-zinc-100">{car.name}</h3>
                      <p className="text-sm text-zinc-400">{car.desc}</p>
                      {!isOwned && <div className="mt-2 text-emerald-400 font-bold font-mono">${car.price}</div>}
                    </div>
                    
                    {isSelected ? (
                      <div className="px-6 py-3 bg-emerald-500/20 text-emerald-400 font-bold rounded-xl border border-emerald-500/50">
                        乗車中
                      </div>
                    ) : isOwned ? (
                      <button
                        onClick={() => setCarModel(car.id)}
                        className="px-6 py-3 bg-zinc-800 hover:bg-zinc-700 text-white font-bold rounded-xl transition-all"
                      >
                        乗り換える
                      </button>
                    ) : (
                      <button
                        disabled={!canAfford}
                        onClick={() => {
                          if (buyCar(car.id, car.price)) soundEngine.playPiron();
                        }}
                        className={`px-6 py-3 font-bold rounded-xl transition-all ${canAfford ? 'bg-amber-500 hover:bg-amber-400 text-black' : 'bg-zinc-800 text-zinc-500 cursor-not-allowed'}`}
                      >
                        購入する
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {activeTab === 'audio' && (
            <div className="space-y-6">
              <div className="bg-zinc-900/80 border border-zinc-800 rounded-2xl p-6">
                <h3 className="text-base font-bold text-zinc-200 mb-2 flex items-center gap-2">
                  <Zap className="w-5 h-5 text-amber-400" />
                  BGMジャンル設定
                </h3>
                <p className="text-xs text-zinc-400 mb-4">
                  走行中に流れるBGMのスタイルを選択します。（簡易シンセサイザーによる自動生成BGM）
                </p>
                <div className="flex flex-wrap gap-3">
                  {(['none', 'Lo-fi', 'Jazz', 'Synthwave'] as const).map(genre => (
                    <button
                      key={genre}
                      onClick={() => handleBgmChange(genre)}
                      className={`px-5 py-3 rounded-xl border font-bold transition-all ${
                        bgmGenre === genre
                          ? 'border-amber-400 bg-amber-500/20 text-amber-400'
                          : 'border-zinc-700 bg-zinc-800 text-zinc-300 hover:bg-zinc-700'
                      }`}
                    >
                      {genre === 'none' ? 'OFF' : genre}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-zinc-800 bg-zinc-950 flex justify-between items-center text-xs text-zinc-500">
          <div>キーボードの [G] キーでいつでもガレージを開閉できます</div>
          <button
            onClick={toggleGarage}
            className="px-6 py-2 bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold rounded-xl transition-all"
          >
            閉じる
          </button>
        </div>
      </div>
    </div>
  );
}
