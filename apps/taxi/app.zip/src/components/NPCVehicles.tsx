import { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { useGameStore } from '../store/gameStore';
import { CELL_SIZE, GRID_WIDTH, GRID_HEIGHT, CellType } from '../utils/mapLogic';
import { soundEngine } from '../utils/audio';

type Direction = 'N' | 'S' | 'E' | 'W';

interface BezierCurve2D {
  p0: THREE.Vector2;
  p1: THREE.Vector2;
  p2: THREE.Vector2;
  approxLength: number;
}

interface NPCCarState {
  id: string;
  pos: THREE.Vector3;
  angle: number;
  direction: Direction;
  targetDirection: Direction;
  speed: number;
  cruiseSpeed: number;
  color: string;
  type: number;
  width: number;
  length: number;

  // 道路追従状態
  roadGridIndex: number; // N/S道路ならgx (4の倍数), E/W道路ならgz (4の倍数)
  targetRoadIndex: number;
  mode: 'STRAIGHT' | 'TURNING';
  turnProgress: number;
  turnCurve: BezierCurve2D | null;
  lastIntersectionId: string;
}

const NPC_COLORS = [
  '#ef4444', '#3b82f6', '#10b981', '#ffffff', '#18181b', 
  '#a855f7', '#f97316', '#06b6d4', '#64748b', '#eab308'
];

const LANE_OFFSET = 3.5; // 車線オフセット (左側通行: 進行方向に対して左側)
const HALF_W = Math.floor(GRID_WIDTH / 2);
const HALF_H = Math.floor(GRID_HEIGHT / 2);

// 方向ごとのベクトルと基本Yaw角度 (N: -Z, S: +Z, E: +X, W: -X)
const DIR_INFO: Record<Direction, { dx: number; dz: number; angle: number }> = {
  N: { dx: 0, dz: -1, angle: Math.PI },
  S: { dx: 0, dz: 1, angle: 0 },
  E: { dx: 1, dz: 0, angle: Math.PI / 2 },
  W: { dx: -1, dz: 0, angle: -Math.PI / 2 },
};

// 道路中心座標から進行方向の左側走行レーン位置を計算
function getLanePos(roadCenterX: number, roadCenterZ: number, dir: Direction): THREE.Vector2 {
  switch (dir) {
    case 'N': return new THREE.Vector2(roadCenterX - LANE_OFFSET, roadCenterZ);
    case 'S': return new THREE.Vector2(roadCenterX + LANE_OFFSET, roadCenterZ);
    case 'E': return new THREE.Vector2(roadCenterX, roadCenterZ - LANE_OFFSET);
    case 'W': return new THREE.Vector2(roadCenterX, roadCenterZ + LANE_OFFSET);
  }
}

// 2次ベジェ曲線の長さ近似
function calculateBezierLength(p0: THREE.Vector2, p1: THREE.Vector2, p2: THREE.Vector2): number {
  const d1 = p0.distanceTo(p1);
  const d2 = p1.distanceTo(p2);
  const chord = p0.distanceTo(p2);
  return (d1 + d2 + chord) / 2;
}

// 2次ベジェ曲線補間
function evaluateBezier(curve: BezierCurve2D, t: number): { pos: THREE.Vector2; angle: number } {
  const u = 1 - t;
  const tt = t * t;
  const uu = u * u;
  const ut2 = 2 * u * t;

  const x = uu * curve.p0.x + ut2 * curve.p1.x + tt * curve.p2.x;
  const y = uu * curve.p0.y + ut2 * curve.p1.y + tt * curve.p2.y;

  // 接線ベクトル
  const dx = 2 * (1 - t) * (curve.p1.x - curve.p0.x) + 2 * t * (curve.p2.x - curve.p1.x);
  const dy = 2 * (1 - t) * (curve.p1.y - curve.p0.y) + 2 * t * (curve.p2.y - curve.p1.y);
  const angle = Math.atan2(dx, dy);

  return { pos: new THREE.Vector2(x, y), angle };
}

export function NPCVehicles() {
  const mapData = useGameStore(state => state.mapData);
  const setNPCCars = useGameStore(state => state.setNPCCars);
  const carPos = useGameStore(state => state.carPos);
  const ultraLowMode = useGameStore(state => state.ultraLowMode);
  
  // 8台のNPC車を生成（必ず有効な道路上のレーンに整列してスポーン）
  const npcs = useMemo<NPCCarState[]>(() => {
    if (!mapData) return [];
    
    const count = 8;
    const cars: NPCCarState[] = [];

    // 利用可能な道路インデックス (4の倍数: 0, 4, 8, ... 40)
    const validRoadIndices: number[] = [];
    for (let i = 0; i < GRID_WIDTH; i += 4) {
      validRoadIndices.push(i);
    }

    for (let i = 0; i < count; i++) {
      const dirs: Direction[] = ['N', 'S', 'E', 'W'];
      const dir = dirs[i % 4];
      const roadIdx = validRoadIndices[(i * 2 + 1) % validRoadIndices.length];
      
      let initX = 0;
      let initZ = 0;

      if (dir === 'N' || dir === 'S') {
        const roadCenterX = (roadIdx - HALF_W) * CELL_SIZE;
        const lane = getLanePos(roadCenterX, 0, dir);
        initX = lane.x;
        // 交差点(4の倍数)を避け、ブロックの真ん中付近に配置
        const offsetBlock = (Math.floor(i * 3) % 8) * 4 + 2;
        initZ = (offsetBlock - HALF_H) * CELL_SIZE;
      } else {
        const roadCenterZ = (roadIdx - HALF_H) * CELL_SIZE;
        const lane = getLanePos(0, roadCenterZ, dir);
        const offsetBlock = (Math.floor(i * 3) % 8) * 4 + 2;
        initX = (offsetBlock - HALF_W) * CELL_SIZE;
        initZ = lane.y;
      }

      cars.push({
        id: `npc-${i}`,
        pos: new THREE.Vector3(initX, 0.8, initZ),
        angle: DIR_INFO[dir].angle,
        direction: dir,
        targetDirection: dir,
        speed: 13 + (i % 3) * 2,
        cruiseSpeed: 13 + (i % 3) * 2,
        color: NPC_COLORS[i % NPC_COLORS.length],
        type: i % 3,
        width: 2.1,
        length: 4.4,
        roadGridIndex: roadIdx,
        targetRoadIndex: roadIdx,
        mode: 'STRAIGHT',
        turnProgress: 0,
        turnCurve: null,
        lastIntersectionId: '',
      });
    }
    return cars;
  }, [mapData]);

  const groupRefs = useRef<(THREE.Group | null)[]>([]);
  const lastHonkTime = useRef(0);

  useFrame((_, delta) => {
    if (!mapData || npcs.length === 0) return;

    const storeCars = [];

    for (let i = 0; i < npcs.length; i++) {
      const npc = npcs[i];
      const grp = groupRefs.current[i];

      // 1. 車間距離・障害物ブレーキシステム
      let speedLimit = npc.cruiseSpeed;
      
      // プレイヤーとの距離
      const toPlayer = new THREE.Vector2(carPos.x - npc.pos.x, carPos.z - npc.pos.z);
      const distToPlayer = toPlayer.length();
      if (distToPlayer < 14) {
        const forward = new THREE.Vector2(Math.sin(npc.angle), Math.cos(npc.angle));
        const dot = forward.dot(toPlayer.clone().normalize());
        if (dot > 0.5) {
          speedLimit = Math.max(0, (distToPlayer - 4.5) * 2.0);
        }
      }

      // 他のNPCとの距離
      for (let j = 0; j < npcs.length; j++) {
        if (i === j) continue;
        const other = npcs[j];
        const toOther = new THREE.Vector2(other.pos.x - npc.pos.x, other.pos.z - npc.pos.z);
        const distToOther = toOther.length();
        if (distToOther < 12) {
          const forward = new THREE.Vector2(Math.sin(npc.angle), Math.cos(npc.angle));
          const dot = forward.dot(toOther.clone().normalize());
          if (dot > 0.6) {
            speedLimit = Math.min(speedLimit, Math.max(0, (distToOther - 4.2) * 2.2));
          }
        }
      }

      // スムーズな加減速
      if (npc.speed < speedLimit) {
        npc.speed = Math.min(speedLimit, npc.speed + 12 * delta);
      } else {
        npc.speed = Math.max(speedLimit, npc.speed - 22 * delta);
      }

      // 2. 移動制御
      if (npc.mode === 'TURNING' && npc.turnCurve) {
        // --- 旋回中 (ベジェ曲線トレース) ---
        const step = (npc.speed / Math.max(1, npc.turnCurve.approxLength)) * delta;
        npc.turnProgress += step;

        if (npc.turnProgress >= 1.0) {
          // 旋回完了 -> 直進モードへ
          npc.mode = 'STRAIGHT';
          npc.direction = npc.targetDirection;
          npc.angle = DIR_INFO[npc.direction].angle;
          npc.pos.x = npc.turnCurve.p2.x;
          npc.pos.z = npc.turnCurve.p2.y;
          npc.roadGridIndex = npc.targetRoadIndex;
          npc.turnCurve = null;
        } else {
          const res = evaluateBezier(npc.turnCurve, npc.turnProgress);
          npc.pos.x = res.pos.x;
          npc.pos.z = res.pos.y;
          npc.angle = res.angle;
        }
      } else {
        // --- 直進中 (STRAIGHT) ---
        const dirInfo = DIR_INFO[npc.direction];
        npc.angle = dirInfo.angle;

        const moveDist = npc.speed * delta;
        npc.pos.x += dirInfo.dx * moveDist;
        npc.pos.z += dirInfo.dz * moveDist;

        // レーンキープ制御 (直進軸と直交する軸を正しい車線位置へ常にスムーズに収束)
        // roadGridIndex は必ず 4 の倍数 (有効な道路の中心)
        if (npc.direction === 'N' || npc.direction === 'S') {
          const targetRoadCenterX = (npc.roadGridIndex - HALF_W) * CELL_SIZE;
          const targetLaneX = targetRoadCenterX + (npc.direction === 'N' ? -LANE_OFFSET : LANE_OFFSET);
          npc.pos.x = THREE.MathUtils.lerp(npc.pos.x, targetLaneX, Math.min(1, 8 * delta));
        } else {
          const targetRoadCenterZ = (npc.roadGridIndex - HALF_H) * CELL_SIZE;
          const targetLaneZ = targetRoadCenterZ + (npc.direction === 'E' ? -LANE_OFFSET : LANE_OFFSET);
          npc.pos.z = THREE.MathUtils.lerp(npc.pos.z, targetLaneZ, Math.min(1, 8 * delta));
        }

        // 現在のグリッド座標
        const currentGridX = npc.pos.x / CELL_SIZE + HALF_W;
        const currentGridZ = npc.pos.z / CELL_SIZE + HALF_H;

        // 進行方向の前方にある最も近い交差点 (4の倍数)
        let nextInterGx = Math.round(currentGridX / 4) * 4;
        let nextInterGz = Math.round(currentGridZ / 4) * 4;

        if (npc.direction === 'N') nextInterGz = Math.floor(currentGridZ / 4) * 4;
        if (npc.direction === 'S') nextInterGz = Math.ceil(currentGridZ / 4) * 4;
        if (npc.direction === 'E') nextInterGx = Math.ceil(currentGridX / 4) * 4;
        if (npc.direction === 'W') nextInterGx = Math.floor(currentGridX / 4) * 4;

        // クランプ
        nextInterGx = Math.max(0, Math.min(GRID_WIDTH - 1, nextInterGx));
        nextInterGz = Math.max(0, Math.min(GRID_HEIGHT - 1, nextInterGz));

        const interCenterX = (nextInterGx - HALF_W) * CELL_SIZE;
        const interCenterZ = (nextInterGz - HALF_H) * CELL_SIZE;
        const distToInter = Math.hypot(npc.pos.x - interCenterX, npc.pos.z - interCenterZ);

        const interId = `${nextInterGx}_${nextInterGz}`;

        // 交差点の手前 7〜11m でルート分岐
        if (
          distToInter <= 10.0 &&
          npc.lastIntersectionId !== interId
        ) {
          npc.lastIntersectionId = interId;

          // 進入可能な方向を判定 (Uターンは除外、マップ境界内の道路のみ)
          const validNextDirs: Direction[] = [];
          
          if (npc.direction !== 'S' && nextInterGz > 0) {
            validNextDirs.push('N');
          }
          if (npc.direction !== 'N' && nextInterGz < GRID_HEIGHT - 1) {
            validNextDirs.push('S');
          }
          if (npc.direction !== 'W' && nextInterGx < GRID_WIDTH - 1) {
            validNextDirs.push('E');
          }
          if (npc.direction !== 'E' && nextInterGx > 0) {
            validNextDirs.push('W');
          }

          let chosenDir = npc.direction;
          // 直進が可能であれば 70% の確率で直進を維持
          if (validNextDirs.includes(npc.direction) && Math.random() < 0.70) {
            chosenDir = npc.direction;
          } else if (validNextDirs.length > 0) {
            // 曲がる (または直進できない端の交差点)
            chosenDir = validNextDirs[Math.floor(Math.random() * validNextDirs.length)];
          } else {
            // どこにも行けない場合は反転
            const opposites: Record<Direction, Direction> = { N: 'S', S: 'N', E: 'W', W: 'E' };
            chosenDir = opposites[npc.direction];
          }

          if (chosenDir !== npc.direction) {
            // 旋回パスの構築
            const p0 = new THREE.Vector2(npc.pos.x, npc.pos.z);

            // 新しい道路のインデックス
            let newRoadGridIndex = npc.roadGridIndex;
            if (chosenDir === 'N' || chosenDir === 'S') {
              newRoadGridIndex = nextInterGx;
            } else {
              newRoadGridIndex = nextInterGz;
            }
            
            // 出口レーン (交差点から目的方向へ 8.5m 先の車線)
            const exitCenter = {
              x: interCenterX + DIR_INFO[chosenDir].dx * 8.5,
              z: interCenterZ + DIR_INFO[chosenDir].dz * 8.5,
            };
            const exitLane = getLanePos(exitCenter.x, exitCenter.z, chosenDir);
            const p2 = exitLane;

            // 制御点 P1: スムーズなカーブ
            const p1 = new THREE.Vector2(
              interCenterX + (p0.x - interCenterX) * 0.4 + (p2.x - interCenterX) * 0.4,
              interCenterZ + (p0.y - interCenterZ) * 0.4 + (p2.y - interCenterZ) * 0.4
            );

            npc.mode = 'TURNING';
            npc.turnProgress = 0;
            npc.targetDirection = chosenDir;
            npc.targetRoadIndex = newRoadGridIndex;
            npc.turnCurve = {
              p0,
              p1,
              p2,
              approxLength: calculateBezierLength(p0, p1, p2),
            };
          }
        }

        // マップ端に達した際の安全な反転 (フェイルセーフ)
        const margin = 0.2;
        if (
          (npc.direction === 'N' && currentGridZ <= margin) ||
          (npc.direction === 'S' && currentGridZ >= GRID_HEIGHT - 1 - margin) ||
          (npc.direction === 'W' && currentGridX <= margin) ||
          (npc.direction === 'E' && currentGridX >= GRID_WIDTH - 1 - margin)
        ) {
          const opposites: Record<Direction, Direction> = { N: 'S', S: 'N', E: 'W', W: 'E' };
          npc.direction = opposites[npc.direction];
          npc.targetDirection = npc.direction;
          npc.lastIntersectionId = '';
        }
      }

      // 3. プレイヤーとの接触判定クラクション
      const distToCar = npc.pos.distanceTo(carPos);
      if (distToCar < 4.0) {
        const now = Date.now();
        if (now - lastHonkTime.current > 1500) {
          soundEngine.playCollision();
          lastHonkTime.current = now;
        }
      }

      if (grp) {
        grp.position.copy(npc.pos);
        grp.rotation.y = npc.angle;
      }

      storeCars.push({
        id: npc.id,
        pos: npc.pos.clone(),
        angle: npc.angle,
        speed: npc.speed,
        color: npc.color,
        type: npc.type
      });
    }

    setNPCCars(storeCars);
  });

  const shouldCastShadow = !ultraLowMode;

  return (
    <group>
      {npcs.map((npc, i) => (
        <group
          key={npc.id}
          ref={(el) => { groupRefs.current[i] = el; }}
          position={[npc.pos.x, npc.pos.y, npc.pos.z]}
        >
          {/* ボディ */}
          <mesh position={[0, 0.4, 0]} castShadow={shouldCastShadow} receiveShadow={shouldCastShadow}>
            <boxGeometry args={[npc.width, 0.9, npc.length]} />
            <meshStandardMaterial color={npc.color} roughness={0.3} metalness={0.5} />
          </mesh>

          {/* キャビン */}
          <mesh position={[0, 1.1, -0.2]} castShadow={shouldCastShadow} receiveShadow={shouldCastShadow}>
            <boxGeometry args={[npc.width - 0.3, 0.7, npc.length * 0.55]} />
            <meshStandardMaterial color="#111827" roughness={0.1} metalness={0.9} />
          </mesh>

          {/* ヘッドライト */}
          <mesh position={[0.7, 0.4, npc.length / 2 + 0.01]}>
            <planeGeometry args={[0.35, 0.2]} />
            <meshBasicMaterial color="#fef08a" />
          </mesh>
          <mesh position={[-0.7, 0.4, npc.length / 2 + 0.01]}>
            <planeGeometry args={[0.35, 0.2]} />
            <meshBasicMaterial color="#fef08a" />
          </mesh>

          {/* テールランプ */}
          <mesh position={[0.7, 0.4, -npc.length / 2 - 0.01]} rotation={[0, Math.PI, 0]}>
            <planeGeometry args={[0.35, 0.2]} />
            <meshBasicMaterial color="#ef4444" />
          </mesh>
          <mesh position={[-0.7, 0.4, -npc.length / 2 - 0.01]} rotation={[0, Math.PI, 0]}>
            <planeGeometry args={[0.35, 0.2]} />
            <meshBasicMaterial color="#ef4444" />
          </mesh>

          {/* タイヤ */}
          <mesh position={[1.05, 0.2, 1.2]} rotation={[0, 0, Math.PI / 2]} castShadow={shouldCastShadow}>
            <cylinderGeometry args={[0.35, 0.35, 0.25, 12]} />
            <meshStandardMaterial color="#18181b" roughness={0.9} />
          </mesh>
          <mesh position={[-1.05, 0.2, 1.2]} rotation={[0, 0, Math.PI / 2]} castShadow={shouldCastShadow}>
            <cylinderGeometry args={[0.35, 0.35, 0.25, 12]} />
            <meshStandardMaterial color="#18181b" roughness={0.9} />
          </mesh>
          <mesh position={[1.05, 0.2, -1.2]} rotation={[0, 0, Math.PI / 2]} castShadow={shouldCastShadow}>
            <cylinderGeometry args={[0.35, 0.35, 0.25, 12]} />
            <meshStandardMaterial color="#18181b" roughness={0.9} />
          </mesh>
          <mesh position={[-1.05, 0.2, -1.2]} rotation={[0, 0, Math.PI / 2]} castShadow={shouldCastShadow}>
            <cylinderGeometry args={[0.35, 0.35, 0.25, 12]} />
            <meshStandardMaterial color="#18181b" roughness={0.9} />
          </mesh>
        </group>
      ))}
    </group>
  );
}
