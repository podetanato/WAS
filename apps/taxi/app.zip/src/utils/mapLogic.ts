import * as THREE from 'three';

export const CELL_SIZE = 20; 
export const GRID_WIDTH = 41; 
export const GRID_HEIGHT = 41;

export enum CellType {
  ROAD,
  BUILDING,
  PARK,
}

export interface MapData {
  grid: CellType[][];
  roads: { x: number; z: number }[];
  buildings: { x: number; z: number; height: number; color: string; scaleX: number; scaleZ: number }[];
  parks: { x: number; z: number }[];
}

const buildingColors = [
  '#f0f0f0', '#dcdcdc', '#2a2a2a', '#4b4b4b', '#1f2937', 
  '#374151', '#4b5563', '#111827', '#6b7280', '#0f172a'
];

export function generateCityMap(): MapData {
  const grid: CellType[][] = [];
  const roads: { x: number; z: number }[] = [];
  const buildings: { x: number; z: number; height: number; color: string; scaleX: number; scaleZ: number }[] = [];
  const parks: { x: number; z: number }[] = [];

  for (let z = 0; z < GRID_HEIGHT; z++) {
    grid[z] = [];
    for (let x = 0; x < GRID_WIDTH; x++) {
      // 道路は4マスごと
      if (x % 4 === 0 || z % 4 === 0) {
        grid[z][x] = CellType.ROAD;
        roads.push({ 
          x: (x - Math.floor(GRID_WIDTH / 2)) * CELL_SIZE, 
          z: (z - Math.floor(GRID_HEIGHT / 2)) * CELL_SIZE 
        });
      } else {
        const posX = (x - Math.floor(GRID_WIDTH / 2)) * CELL_SIZE;
        const posZ = (z - Math.floor(GRID_HEIGHT / 2)) * CELL_SIZE;
        
        if (Math.random() > 0.85) {
          grid[z][x] = CellType.PARK;
          parks.push({ x: posX, z: posZ });
        } else {
          grid[z][x] = CellType.BUILDING;
          
          // 建物のディテール（高さをランダムに、幅をセルのサイズに合わせる）
          const isSkyscraper = Math.random() > 0.9;
          const height = isSkyscraper ? 30 + Math.random() * 50 : 10 + Math.random() * 20;
          const color = buildingColors[Math.floor(Math.random() * buildingColors.length)];
          
          buildings.push({ 
            x: posX, 
            z: posZ, 
            height, 
            color,
            scaleX: CELL_SIZE * (0.6 + Math.random() * 0.3),
            scaleZ: CELL_SIZE * (0.6 + Math.random() * 0.3)
          });
        }
      }
    }
  }
  return { grid, roads, buildings, parks };
}

export function getRandomRoadPosition(roads: { x: number; z: number }[]) {
  const r = roads[Math.floor(Math.random() * roads.length)];
  return new THREE.Vector3(r.x, 0, r.z);
}
