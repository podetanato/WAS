class SoundEngine {
  ctx: AudioContext | null = null;
  engineOsc: OscillatorNode | null = null;
  engineGain: GainNode | null = null;
  skidNode: AudioBufferSourceNode | null = null;
  skidGain: GainNode | null = null;
  volume: number = 0.5;
  initialized: boolean = false;
  noiseBuffer: AudioBuffer | null = null;
  nitroOsc: OscillatorNode | null = null;
  nitroGain: GainNode | null = null;
  
  bgmGenre: 'none' | 'Lo-fi' | 'Jazz' | 'Synthwave' = 'none';
  bgmInterval: number | null = null;
  bgmNoteIndex: number = 0;

  init() {
    if (this.initialized) return;
    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
      
      // ノイズバッファの事前生成（スキッド音用）
      const bufferSize = this.ctx.sampleRate * 2;
      this.noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const output = this.noiseBuffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        output[i] = Math.random() * 2 - 1;
      }
      
      this.initialized = true;
    } catch (e) {
      console.warn('Web Audio API not supported', e);
    }
  }

  setVolume(v: number) {
    this.volume = v;
    if (this.engineGain && this.ctx) {
      this.engineGain.gain.setTargetAtTime(v * 0.15, this.ctx.currentTime, 0.1);
    }
  }

  startEngine() {
    if (!this.ctx) this.init();
    if (!this.ctx || this.engineOsc) return;

    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }

    this.engineOsc = this.ctx.createOscillator();
    this.engineOsc.type = 'sawtooth';
    
    // エンジン音を少しマイルドにするフィルター
    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = 400;

    this.engineGain = this.ctx.createGain();
    this.engineGain.gain.value = this.volume * 0.15; // 基本音量

    this.engineOsc.connect(filter);
    filter.connect(this.engineGain);
    this.engineGain.connect(this.ctx.destination);
    
    this.engineOsc.start();
  }

  updateEngine(rpm: number) {
    if (!this.ctx || !this.engineOsc) {
      if (rpm > 0.1) this.startEngine();
      return;
    }
    
    const targetFreq = 40 + (rpm * 150);
    this.engineOsc.frequency.setTargetAtTime(targetFreq, this.ctx.currentTime, 0.1);
  }

  updateDrift(isDrifting: boolean, intensity: number = 1.0) {
    if (!this.ctx || !this.noiseBuffer || this.volume === 0) return;

    if (isDrifting) {
      if (!this.skidGain) {
        const source = this.ctx.createBufferSource();
        source.buffer = this.noiseBuffer;
        source.loop = true;

        const filter = this.ctx.createBiquadFilter();
        filter.type = 'bandpass';
        filter.frequency.value = 1200;
        filter.Q.value = 4.0;

        const gain = this.ctx.createGain();
        gain.gain.value = 0;

        source.connect(filter);
        filter.connect(gain);
        gain.connect(this.ctx.destination);
        source.start();

        this.skidNode = source;
        this.skidGain = gain;
      }
      const targetGain = Math.min(this.volume * 0.3 * intensity, 0.35);
      this.skidGain.gain.setTargetAtTime(targetGain, this.ctx.currentTime, 0.05);
    } else if (this.skidGain) {
      this.skidGain.gain.setTargetAtTime(0, this.ctx.currentTime, 0.08);
    }
  }

  updateNitro(isNitro: boolean) {
    if (!this.ctx || this.volume === 0) return;

    if (isNitro) {
      if (!this.nitroGain) {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(320, this.ctx.currentTime);
        gain.gain.setValueAtTime(0, this.ctx.currentTime);

        const filter = this.ctx.createBiquadFilter();
        filter.type = 'lowpass';
        filter.frequency.value = 1800;

        osc.connect(filter);
        filter.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start();

        this.nitroOsc = osc;
        this.nitroGain = gain;
      }
      this.nitroGain.gain.setTargetAtTime(this.volume * 0.25, this.ctx.currentTime, 0.05);
      if (this.nitroOsc) {
        this.nitroOsc.frequency.setTargetAtTime(480, this.ctx.currentTime, 0.1);
      }
    } else if (this.nitroGain) {
      this.nitroGain.gain.setTargetAtTime(0, this.ctx.currentTime, 0.1);
    }
  }

  playCollision() {
    if (!this.ctx || this.volume === 0) return;
    
    const osc = this.ctx.createOscillator();
    osc.type = 'square';
    
    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = 1000;

    const gain = this.ctx.createGain();
    
    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.ctx.destination);
    
    const now = this.ctx.currentTime;
    // ぶつかった瞬間の音 (低音のドンッ)
    osc.frequency.setValueAtTime(100, now);
    osc.frequency.exponentialRampToValueAtTime(10, now + 0.3);
    
    gain.gain.setValueAtTime(this.volume * 0.8, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.3);
    
    osc.start(now);
    osc.stop(now + 0.3);
  }

  playPiron() {
    if (!this.ctx || this.volume === 0) return;

    const osc = this.ctx.createOscillator();
    osc.type = 'sine';
    
    const gain = this.ctx.createGain();
    
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    
    const now = this.ctx.currentTime;
    
    // ピロン♪ (高音のA5 -> E6)
    osc.frequency.setValueAtTime(880, now); // A5
    osc.frequency.setValueAtTime(1318.51, now + 0.1); // E6
    
    gain.gain.setValueAtTime(0, now);
    gain.gain.linearRampToValueAtTime(this.volume * 0.6, now + 0.05);
    gain.gain.setValueAtTime(this.volume * 0.6, now + 0.1);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.5);
    
    osc.start(now);
    osc.stop(now + 0.5);
  }

  updateBGM(genre: 'none' | 'Lo-fi' | 'Jazz' | 'Synthwave') {
    if (this.bgmGenre === genre) return;
    this.bgmGenre = genre;
    
    if (this.bgmInterval) {
      window.clearInterval(this.bgmInterval);
      this.bgmInterval = null;
    }
    
    this.bgmNoteIndex = 0;
    
    if (genre === 'none' || this.volume === 0) return;
    if (!this.ctx) this.init();
    if (this.ctx?.state === 'suspended') this.ctx.resume();
    
    let tempo = 120;
    if (genre === 'Lo-fi') tempo = 80;
    else if (genre === 'Jazz') tempo = 140;
    else if (genre === 'Synthwave') tempo = 128;
    
    const intervalMs = (60 / tempo) * 1000 / 2; // 8th notes
    
    this.bgmInterval = window.setInterval(() => this.playBGMStep(), intervalMs);
  }

  playBGMStep() {
    if (!this.ctx || this.volume === 0 || this.bgmGenre === 'none') return;
    
    const now = this.ctx.currentTime;
    const i = this.bgmNoteIndex;
    
    if (this.bgmGenre === 'Synthwave') {
      // 16th notes feel (called on 8th, so we double it mentally or just play 8ths)
      // Synth bass arpeggio
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const filter = this.ctx.createBiquadFilter();
      
      osc.type = 'sawtooth';
      
      const notes = [65.41, 65.41, 77.78, 65.41, 98.00, 77.78, 65.41, 49.00]; // C2, Eb2, G2 etc
      osc.frequency.value = notes[i % notes.length];
      
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(800, now);
      filter.frequency.exponentialRampToValueAtTime(100, now + 0.2);
      
      gain.gain.setValueAtTime(this.volume * 0.15, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.2);
      
      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);
      
      osc.start(now);
      osc.stop(now + 0.2);
      
      // Kick drum on every 4th step (every beat)
      if (i % 2 === 0) {
        const kickOsc = this.ctx.createOscillator();
        const kickGain = this.ctx.createGain();
        kickOsc.frequency.setValueAtTime(150, now);
        kickOsc.frequency.exponentialRampToValueAtTime(40, now + 0.1);
        kickGain.gain.setValueAtTime(this.volume * 0.3, now);
        kickGain.gain.exponentialRampToValueAtTime(0.01, now + 0.1);
        kickOsc.connect(kickGain);
        kickGain.connect(this.ctx.destination);
        kickOsc.start(now);
        kickOsc.stop(now + 0.1);
      }
    } else if (this.bgmGenre === 'Lo-fi') {
      // Slow electric piano chords + vinyl noise
      if (i % 8 === 0 || i % 8 === 3) {
        const chord = i % 16 < 8 ? [261.63, 311.13, 392.00, 493.88] : [220.00, 261.63, 329.63, 440.00]; // Cm7 then Am7
        chord.forEach((freq) => {
          const osc = this.ctx!.createOscillator();
          const gain = this.ctx!.createGain();
          osc.type = 'sine';
          osc.frequency.value = freq;
          
          gain.gain.setValueAtTime(0, now);
          gain.gain.linearRampToValueAtTime(this.volume * 0.05, now + 0.1);
          gain.gain.exponentialRampToValueAtTime(0.01, now + 1.5);
          
          osc.connect(gain);
          gain.connect(this.ctx!.destination);
          
          osc.start(now);
          osc.stop(now + 1.5);
        });
      }
      // Simple hi-hat
      if (i % 2 === 0) {
         if (this.noiseBuffer) {
           const src = this.ctx.createBufferSource();
           src.buffer = this.noiseBuffer;
           const gain = this.ctx.createGain();
           const filter = this.ctx.createBiquadFilter();
           filter.type = 'highpass';
           filter.frequency.value = 5000;
           
           gain.gain.setValueAtTime(this.volume * 0.05, now);
           gain.gain.exponentialRampToValueAtTime(0.01, now + 0.05);
           
           src.connect(filter);
           filter.connect(gain);
           gain.connect(this.ctx.destination);
           src.start(now);
           src.stop(now + 0.05);
         }
      }
    } else if (this.bgmGenre === 'Jazz') {
      // Walking bass
      const bassOsc = this.ctx.createOscillator();
      const bassGain = this.ctx.createGain();
      bassOsc.type = 'triangle';
      
      const bassNotes = [65.41, 73.42, 82.41, 87.31, 98.00, 87.31, 82.41, 73.42]; // C2, D2, E2, F2, G2, F2, E2, D2
      bassOsc.frequency.value = bassNotes[i % bassNotes.length];
      
      bassGain.gain.setValueAtTime(this.volume * 0.15, now);
      bassGain.gain.linearRampToValueAtTime(this.volume * 0.1, now + 0.1);
      bassGain.gain.exponentialRampToValueAtTime(0.01, now + 0.4);
      
      bassOsc.connect(bassGain);
      bassGain.connect(this.ctx.destination);
      bassOsc.start(now);
      bassOsc.stop(now + 0.4);
      
      // Ride cymbal swing (on 0, 1.5 roughly, but we are on 8ths so on 0, 2, 3)
      if (i % 4 === 0 || i % 4 === 2 || i % 4 === 3) {
         if (this.noiseBuffer) {
           const src = this.ctx.createBufferSource();
           src.buffer = this.noiseBuffer;
           const gain = this.ctx.createGain();
           const filter = this.ctx.createBiquadFilter();
           filter.type = 'bandpass';
           filter.frequency.value = 8000;
           
           gain.gain.setValueAtTime(this.volume * 0.08, now);
           gain.gain.exponentialRampToValueAtTime(0.01, now + 0.3);
           
           src.connect(filter);
           filter.connect(gain);
           gain.connect(this.ctx.destination);
           src.start(now);
           src.stop(now + 0.3);
         }
      }
    }
    
    this.bgmNoteIndex++;
  }
}

export const soundEngine = new SoundEngine();
