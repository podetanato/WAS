// WAS (Web App Store) Integration Bridge
// Specification for appId: 'taxi'

export const WAS_APP_ID = 'taxi';
export const WAS_VERSION = '1.0.0';

export const WAS_STORAGE_KEYS = {
  primary: `was_${WAS_APP_ID}_save`,
  fallback: `${WAS_APP_ID}_saveData`,
  legacy: `was:${WAS_APP_ID}:save`,
  compact: WAS_APP_ID,
};

export interface WASSaveData {
  appId: 'taxi';
  version: string;
  updatedAt: number;
  score: number;
  ownedCars: ('classic' | 'sport' | 'hyper')[];
  carModel: 'classic' | 'sport' | 'hyper';
  carUpgrades: {
    topSpeed: number;
    acceleration: number;
    handling: number;
    nitro: number;
    spoiler: number;
    neonColor: string;
    bodyColor: string;
  };
  settings: {
    showControls: boolean;
    enableShadows: boolean;
    ultraLowMode: boolean;
    soundVolume: number;
    bgmGenre: 'none' | 'Lo-fi' | 'Jazz' | 'Synthwave';
    cameraMode: 'TPS' | 'FPS';
  };
  stats: {
    passengersDelivered: number;
    totalFaresEarned: number;
  };
}

export const DEFAULT_WAS_DATA: WASSaveData = {
  appId: 'taxi',
  version: WAS_VERSION,
  updatedAt: Date.now(),
  score: 0,
  ownedCars: ['classic'],
  carModel: 'classic',
  carUpgrades: {
    topSpeed: 1,
    acceleration: 1,
    handling: 1,
    nitro: 1,
    spoiler: 0,
    neonColor: '#38bdf8',
    bodyColor: '#fbbf24',
  },
  settings: {
    showControls: true,
    enableShadows: true,
    ultraLowMode: false,
    soundVolume: 0.5,
    bgmGenre: 'none',
    cameraMode: 'TPS',
  },
  stats: {
    passengersDelivered: 0,
    totalFaresEarned: 0,
  },
};

/**
 * Load saved data from localStorage across WAS keys
 */
export function loadWASData(): WASSaveData {
  if (typeof window === 'undefined' || !window.localStorage) {
    return DEFAULT_WAS_DATA;
  }

  const keysToTry = [
    WAS_STORAGE_KEYS.primary,
    WAS_STORAGE_KEYS.fallback,
    WAS_STORAGE_KEYS.legacy,
    WAS_STORAGE_KEYS.compact,
  ];

  for (const key of keysToTry) {
    try {
      const raw = localStorage.getItem(key);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed === 'object') {
          return {
            ...DEFAULT_WAS_DATA,
            ...parsed,
            appId: 'taxi',
            carUpgrades: {
              ...DEFAULT_WAS_DATA.carUpgrades,
              ...(parsed.carUpgrades || {}),
            },
            settings: {
              ...DEFAULT_WAS_DATA.settings,
              ...(parsed.settings || {}),
            },
            stats: {
              ...DEFAULT_WAS_DATA.stats,
              ...(parsed.stats || {}),
            },
          };
        }
      }
    } catch (e) {
      console.warn(`[WAS:taxi] Failed to read key ${key}:`, e);
    }
  }

  return DEFAULT_WAS_DATA;
}

/**
 * Save data to localStorage and broadcast to WAS parent via postMessage
 */
export function saveWASData(data: Partial<WASSaveData>): WASSaveData {
  const current = loadWASData();
  const merged: WASSaveData = {
    ...current,
    ...data,
    appId: 'taxi',
    version: WAS_VERSION,
    updatedAt: Date.now(),
    carUpgrades: {
      ...current.carUpgrades,
      ...(data.carUpgrades || {}),
    },
    settings: {
      ...current.settings,
      ...(data.settings || {}),
    },
    stats: {
      ...current.stats,
      ...(data.stats || {}),
    },
  };

  if (typeof window !== 'undefined' && window.localStorage) {
    try {
      const json = JSON.stringify(merged);
      localStorage.setItem(WAS_STORAGE_KEYS.primary, json);
      localStorage.setItem(WAS_STORAGE_KEYS.fallback, json);
    } catch (e) {
      console.error('[WAS:taxi] LocalStorage write failed:', e);
    }
  }

  // Send to WAS parent window if embedded in iframe
  postToWAS('WAS_SAVE', { data: merged });
  postToWAS('WAS_SCORE', { score: Math.floor(merged.score) });

  return merged;
}

/**
 * Clear all WAS save data for 'taxi'
 */
export function clearWASData(): void {
  if (typeof window !== 'undefined' && window.localStorage) {
    localStorage.removeItem(WAS_STORAGE_KEYS.primary);
    localStorage.removeItem(WAS_STORAGE_KEYS.fallback);
    localStorage.removeItem(WAS_STORAGE_KEYS.legacy);
    localStorage.removeItem(WAS_STORAGE_KEYS.compact);
  }
  postToWAS('WAS_CLEAR', {});
}

/**
 * Send postMessage to WAS host frame
 */
export function postToWAS(type: string, payload: Record<string, unknown> = {}): void {
  if (typeof window === 'undefined') return;

  const message = {
    appId: WAS_APP_ID,
    type,
    timestamp: Date.now(),
    ...payload,
  };

  // Dispatch to parent if running in iframe
  if (window.parent && window.parent !== window) {
    try {
      window.parent.postMessage(message, '*');
    } catch (e) {
      console.warn('[WAS:taxi] postMessage failed:', e);
    }
  }

  // Also dispatch standard custom event for local consumers
  try {
    window.dispatchEvent(new CustomEvent('was_message', { detail: message }));
  } catch {
    // Ignore in non-browser
  }
}

/**
 * Notify WAS system that the app is mounted and ready
 */
export function notifyWASReady(): void {
  postToWAS('WAS_READY', {
    name: 'Taxi Simulator 3D',
    version: WAS_VERSION,
  });
  // Compatibility shorthand
  postToWAS('ready', { id: WAS_APP_ID });
}

/**
 * Request exit back to Web App Store
 */
export function exitToWAS(): void {
  // Save current state first
  postToWAS('WAS_EXIT', {});
  postToWAS('EXIT_APP', {});

  // Fallback if standalone: try history back or show alert message
  if (window.parent === window) {
    if (window.history.length > 1) {
      window.history.back();
    } else {
      window.location.href = '/';
    }
  }
}

// Expose on window for runtime verification and WAS container inspection
if (typeof window !== 'undefined') {
  (window as unknown as { __WAS_APP__: unknown }).__WAS_APP__ = {
    id: WAS_APP_ID,
    version: WAS_VERSION,
    load: loadWASData,
    save: saveWASData,
    clear: clearWASData,
    post: postToWAS,
  };
}
