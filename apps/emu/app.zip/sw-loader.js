// [WAS対応] このアプリ自身の Service Worker 登録を無効化。
// WAS（Web App Store）本体が既に /sw.js でオフラインキャッシュ・配信を一元管理しているため、
// アプリ側が独自に Service Worker を登録すると、スコープの競合や
// WAS本体のオフライン機能の破壊につながる。
//
// 元のコード:
// if ('serviceWorker' in navigator) {
//     navigator.serviceWorker.register('/sw.js').then(function(reg) {
//         console.log('Registration succeeded. Scope is ' + reg.scope);
//     }).catch(function(error) {
//         console.log('Registration failed with ' + error);
//     });
// }

// [WAS対応] PWAインストールプロンプトも無効化。
// このアプリは WAS ストアの中の1画面として動作するため、
// 独自に「ホーム画面に追加」を促す必要がない（WAS自体が既にPWA）。
//
// 元のコード:
// (function() {
//     var cnt = 0;
//     window.onbeforeinstallprompt = function(e) {
//         cnt += 1;
//         if (cnt > 2) { return; }
//         e.preventDefault();
//         var deferredPrompt = e;
//         window.onclick = function(e) {
//             deferredPrompt.prompt();
//             window.onclick = null;
//         }
//     };
// })();